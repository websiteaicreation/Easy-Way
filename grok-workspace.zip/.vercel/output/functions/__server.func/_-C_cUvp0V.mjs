import { b as Link, w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-C_cUvp0V.js
var import_jsx_runtime = require_jsx_runtime();
function MissingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "empty",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "That page is not on the shelf." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The link may be old, or it was never part of this demo." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "btn primary",
					to: "/",
					children: "Back to trending"
				})
			]
		})
	});
}
//#endregion
export { MissingPage as component };
