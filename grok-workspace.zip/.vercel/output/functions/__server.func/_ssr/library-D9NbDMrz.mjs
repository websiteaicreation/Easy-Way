import { b as slugify, c as CATALOG, f as artForCategory, l as CATEGORIES, v as parseDuration } from "./router-D2jjv7p6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-D9NbDMrz.js
var UPLOADS_KEY = "afterdark-uploads";
var SAVED_KEY = "afterdark-saved";
var LIKES_KEY = "afterdark-likes";
var COMMENTS_KEY = "afterdark-comments";
var REPORTS_KEY = "afterdark-reports";
var MEMBER_KEY = "afterdark-member";
var FOLLOWS_KEY = "afterdark-follows";
var THREADS_KEY = "afterdark-threads";
var LIBRARY_EVENT = "afterdark-sync";
function canUseStorage() {
	return typeof window !== "undefined" && typeof localStorage !== "undefined";
}
function readJson(key, fallback) {
	if (!canUseStorage()) return fallback;
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
function writeJson(key, value) {
	if (!canUseStorage()) return;
	localStorage.setItem(key, JSON.stringify(value));
	window.dispatchEvent(new Event(LIBRARY_EVENT));
}
function isCategory(value) {
	return typeof value === "string" && CATEGORIES.includes(value);
}
function isVideo(value) {
	if (!value || typeof value !== "object") return false;
	const video = value;
	return typeof video.slug === "string" && typeof video.title === "string" && typeof video.creator === "string" && typeof video.category === "string" && typeof video.duration === "string" && typeof video.durationSec === "number" && typeof video.synopsis === "string";
}
function loadUploads() {
	return readJson(UPLOADS_KEY, []).filter(isVideo).map((video) => ({
		...video,
		views: video.views || "New",
		viewsNum: video.viewsNum || 0,
		time: video.time || 0,
		category: isCategory(video.category) ? video.category : "Mature",
		art: video.art || artForCategory(isCategory(video.category) ? video.category : "Mature"),
		local: true
	}));
}
function loadSaved() {
	return readJson(SAVED_KEY, []).filter((item) => typeof item === "string");
}
function loadLikes() {
	return readJson(LIKES_KEY, []).filter((item) => typeof item === "string");
}
function loadComments(slug) {
	return readJson(COMMENTS_KEY, []).filter((comment) => comment && comment.slug === slug && typeof comment.text === "string" && typeof comment.user === "string").sort((a, b) => b.at - a.at);
}
function loadReports() {
	return readJson(REPORTS_KEY, []).filter((report) => report && typeof report.reason === "string").sort((a, b) => b.at - a.at);
}
function uniqueSlug(title) {
	const taken = /* @__PURE__ */ new Set([...CATALOG.map((video) => video.slug), ...loadUploads().map((video) => video.slug)]);
	const base = slugify(title);
	if (!taken.has(base)) return base;
	let n = 2;
	while (taken.has(`${base}-${n}`)) n += 1;
	return `${base}-${n}`;
}
function addUpload(input) {
	const title = input.title.trim();
	const creator = input.creator.trim();
	const synopsis = input.synopsis.trim();
	const durationSec = parseDuration(input.duration);
	if (title.length < 3) return { error: "Give the video a title of at least 3 characters." };
	if (title.length > 80) return { error: "Keep the title under 80 characters." };
	if (creator.length < 2) return { error: "Add the creator name." };
	if (creator.length > 40) return { error: "Creator name is too long." };
	if (durationSec == null) return { error: "Duration should look like 08:16, under 3 hours." };
	if (synopsis.length < 12) return { error: "Add a short synopsis — at least a sentence." };
	if (synopsis.length > 280) return { error: "Synopsis must stay under 280 characters." };
	if (loadUploads().length >= 24) return { error: "This demo shelf holds 24 uploads. Remove one first." };
	const minutes = Math.floor(durationSec / 60);
	const seconds = durationSec % 60;
	const video = {
		slug: uniqueSlug(title),
		title,
		creator,
		category: input.category,
		views: "New",
		viewsNum: 0,
		duration: `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`,
		durationSec,
		time: Date.now(),
		art: artForCategory(input.category),
		synopsis,
		local: true
	};
	writeJson(UPLOADS_KEY, [video, ...loadUploads()]);
	return { video };
}
function removeUpload(slug) {
	writeJson(UPLOADS_KEY, loadUploads().filter((video) => video.slug !== slug));
	writeJson(SAVED_KEY, loadSaved().filter((item) => item !== slug));
	writeJson(LIKES_KEY, loadLikes().filter((item) => item !== slug));
}
function toggleId(key, slug) {
	const current = readJson(key, []).filter((item) => typeof item === "string");
	const has = current.includes(slug);
	writeJson(key, has ? current.filter((item) => item !== slug) : [slug, ...current]);
	return !has;
}
function toggleSaved(slug) {
	return toggleId(SAVED_KEY, slug);
}
function toggleLike(slug) {
	return toggleId(LIKES_KEY, slug);
}
function addComment(slug, user, text) {
	const name = user.trim() || "Guest";
	const body = text.trim();
	if (name.length > 32) return { error: "Name must be under 32 characters." };
	if (body.length < 2) return { error: "Write a comment first." };
	if (body.length > 400) return { error: "Comments stay under 400 characters." };
	writeJson(COMMENTS_KEY, [{
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
		slug,
		user: name,
		text: body,
		at: Date.now()
	}, ...readJson(COMMENTS_KEY, [])].slice(0, 200));
	return {};
}
function addReport(input) {
	const target = input.target.trim();
	const details = input.details.trim();
	if (!input.reason) return { error: "Choose a reason." };
	if (target.length < 2) return { error: "Say what you are reporting." };
	if (details.length < 8) return { error: "Add a few details so a moderator could act." };
	if (details.length > 500) return { error: "Keep the note under 500 characters." };
	writeJson(REPORTS_KEY, [{
		id: `${Date.now()}`,
		target: target.slice(0, 120),
		reason: input.reason,
		details,
		at: Date.now()
	}, ...loadReports()].slice(0, 40));
	return {};
}
function loadMemberName() {
	if (!canUseStorage()) return "";
	return (localStorage.getItem(MEMBER_KEY) ?? "").slice(0, 32);
}
function setMemberName(name) {
	if (!canUseStorage()) return;
	const next = name.trim().slice(0, 32);
	if (!next) localStorage.removeItem(MEMBER_KEY);
	else localStorage.setItem(MEMBER_KEY, next);
	window.dispatchEvent(new Event(LIBRARY_EVENT));
}
function loadFollows() {
	return readJson(FOLLOWS_KEY, []).filter((item) => typeof item === "string");
}
function toggleFollow(slug) {
	const current = loadFollows();
	writeJson(FOLLOWS_KEY, current.includes(slug) ? current.filter((item) => item !== slug) : [slug, ...current]);
}
var SEED_THREADS = [{
	id: "seed-schedules",
	title: "How do you film a short without rushing the last take?",
	body: "Studio June leaves the last ten minutes unscripted. Curious what other sets do when the light is already gone.",
	author: "Hana",
	at: 0,
	replies: [{
		id: "seed-schedules-1",
		author: "Lena",
		body: "We stop. A tired take reads as tired, and the edit cannot hide that.",
		at: 0
	}]
}, {
	id: "seed-morocco",
	title: "Shooting in Marrakech without turning the city into a backdrop",
	body: "Mila’s riad films feel lived-in. What do you ask a location before you bring a camera in?",
	author: "Nora",
	at: 0,
	replies: []
}];
function isThread(value) {
	if (!value || typeof value !== "object") return false;
	const thread = value;
	return typeof thread.id === "string" && typeof thread.title === "string" && typeof thread.body === "string" && typeof thread.author === "string" && Array.isArray(thread.replies);
}
function loadThreads() {
	if (!canUseStorage() || localStorage.getItem(THREADS_KEY) == null) return SEED_THREADS;
	return readJson(THREADS_KEY, []).filter(isThread);
}
function addThread(input) {
	const title = input.title.trim();
	const body = input.body.trim();
	const author = input.author.trim() || "Guest";
	if (title.length < 4) return { error: "Give the thread a title." };
	if (title.length > 90) return { error: "Keep the title under 90 characters." };
	if (body.length < 8) return { error: "Write a little more so people can reply." };
	if (body.length > 500) return { error: "Keep the post under 500 characters." };
	if (author.length > 32) return { error: "Name must be under 32 characters." };
	writeJson(THREADS_KEY, [{
		id: `${Date.now()}`,
		title,
		body,
		author,
		at: Date.now(),
		replies: []
	}, ...loadThreads()].slice(0, 40));
	return {};
}
function addReply(threadId, input) {
	const body = input.body.trim();
	const author = input.author.trim() || "Guest";
	if (body.length < 2) return { error: "Write a reply first." };
	if (body.length > 400) return { error: "Replies stay under 400 characters." };
	if (author.length > 32) return { error: "Name must be under 32 characters." };
	const threads = loadThreads();
	const index = threads.findIndex((thread) => thread.id === threadId);
	if (index < 0) return { error: "That thread is gone." };
	const reply = {
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
		author,
		body,
		at: Date.now()
	};
	const current = threads[index];
	const next = [...threads];
	next[index] = {
		...current,
		replies: [...current.replies, reply].slice(-30)
	};
	writeJson(THREADS_KEY, next);
	return {};
}
//#endregion
export { toggleFollow as _, addThread as a, loadFollows as c, loadReports as d, loadSaved as f, setMemberName as g, removeUpload as h, addReport as i, loadLikes as l, loadUploads as m, addComment as n, addUpload as o, loadThreads as p, addReply as r, loadComments as s, LIBRARY_EVENT as t, loadMemberName as u, toggleLike as v, toggleSaved as y };
