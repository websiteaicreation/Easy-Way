import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Sparkles } from "../_libs/lucide-react.mjs";
import { l as CATEGORIES, p as chipLabel, s as useBrowse, u as CREATORS } from "./router-D2jjv7p6.mjs";
import { n as VideoCard } from "./video-card-D54OchWJ.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B0Vg2Fmo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PER_PAGE = 9;
function HomePage() {
	const { videos, saved } = useLibrary();
	const query = useBrowse((state) => state.query);
	const category = useBrowse((state) => state.category);
	const lane = useBrowse((state) => state.lane);
	const sort = useBrowse((state) => state.sort);
	const page = useBrowse((state) => state.page);
	const setCategory = useBrowse((state) => state.setCategory);
	const setSort = useBrowse((state) => state.setSort);
	const setPage = useBrowse((state) => state.setPage);
	useBrowse((state) => state.setQuery);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		const next = [...videos.filter((video) => {
			if (category === "Saved" && !saved.includes(video.slug)) return false;
			if (category !== "All" && category !== "Saved" && video.category !== category) return false;
			if (lane === "featured" && !video.featured) return false;
			if (lane === "clips" && video.kind !== "clip") return false;
			if (lane === "shorties" && video.kind !== "short") return false;
			if (lane === "gifs" && video.kind !== "gif") return false;
			if (lane === "photos" && video.kind !== "photo") return false;
			if (lane === "morocco" && video.region !== "morocco") return false;
			if (!needle) return true;
			return `${video.title} ${video.creator} ${video.category}`.toLowerCase().includes(needle);
		})];
		if (sort === "popular") next.sort((a, b) => b.viewsNum - a.viewsNum || b.time - a.time);
		if (sort === "newest") next.sort((a, b) => b.time - a.time);
		if (sort === "short") next.sort((a, b) => a.durationSec - b.durationSec);
		return next;
	}, [
		videos,
		saved,
		query,
		category,
		lane,
		sort
	]);
	const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
	const safePage = Math.min(page, pages);
	(0, import_react.useEffect)(() => {
		if (page !== safePage) setPage(safePage);
	}, [
		page,
		safePage,
		setPage
	]);
	const shelfTitle = lane === "featured" ? "Featured videos" : lane === "clips" ? "Clips" : lane === "shorties" ? "Shorties" : lane === "recommended" ? "Recommended videos" : lane === "morocco" ? "Hottest in Morocco" : lane === "gifs" ? "Porn GIFs" : lane === "photos" ? "Photos" : category === "Saved" ? "Playlists" : category !== "All" ? category : "Trending videos";
	const shown = filtered.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE);
	const chips = [
		"All",
		...CATEGORIES,
		"Saved"
	];
	function countFor(id) {
		if (id === "All") return videos.length;
		if (id === "Saved") return videos.filter((video) => saved.includes(video.slug)).length;
		return videos.filter((video) => video.category === id).length;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "promo",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "EASY WAY ORIGINALS" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Discover creator-led stories, interviews, and behind-the-scenes features." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						hash: "creators",
						children: "EXPLORE"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "discover",
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "section-kicker",
					children: [
						filtered.length,
						" ",
						filtered.length === 1 ? "video" : "videos",
						query ? ` for “${query}”` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
					shelfTitle,
					" ",
					shelfTitle === "Trending videos" || lane === "morocco" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
						className: "hot-mark",
						size: 16,
						"aria-hidden": "true"
					}) : null
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "Sort videos",
					value: sort,
					onChange: (event) => setSort(event.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "popular",
							children: "Most popular"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "newest",
							children: "Newest first"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "short",
							children: "Shortest first"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "chips-wrap",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "chips",
					role: "toolbar",
					"aria-label": "Filter videos",
					children: chips.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: category === id ? "chip selected" : "chip",
						"aria-pressed": category === id,
						onClick: () => setCategory(id),
						children: id === "Saved" && saved.length > 0 ? `Saved · ${saved.length}` : chipLabel(id)
					}, id))
				})
			}),
			shown.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "video-grid",
				children: shown.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video }, video.slug))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "empty",
				children: "No results found. Try another search or category."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pagination",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost",
						type: "button",
						disabled: safePage === 1,
						onClick: () => setPage(safePage - 1),
						children: "Previous"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Page ",
						safePage,
						" of ",
						pages
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost",
						type: "button",
						disabled: safePage === pages,
						onClick: () => setPage(safePage + 1),
						children: "Next"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "categories",
				className: "section-head",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "BROWSE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Top categories" })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cat-grid",
				children: CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: category === item ? "cat-tile selected" : "cat-tile",
					onClick: () => {
						setCategory(item);
						document.getElementById("discover")?.scrollIntoView({
							behavior: "smooth",
							block: "start"
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: chipLabel(item) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: countFor(item) === 1 ? "1 video" : `${countFor(item)} videos` })]
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "creators",
				className: "creator-strip",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "MADE BY CREATORS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Creator-first, community-minded." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tools for verified adults, transparent moderation, and respectful communities." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "btn outline",
					to: "/studio",
					children: "Open creator studio →"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "creator-row",
				children: CREATORS.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/creator/$slug",
					params: { slug: creator.slug },
					className: "creator-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `avatar thumb-art art-${creator.art}`,
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: creator.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						creator.place,
						" — ",
						creator.bio
					] })] })]
				}, creator.slug))
			})
		]
	});
}
//#endregion
export { HomePage as component };
