import { o as __toESM } from "../_runtime.mjs";
import { S as useNavigate, Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useToast, l as CATEGORIES } from "./router-D2jjv7p6.mjs";
import { h as removeUpload, o as addUpload } from "./library-D9NbDMrz.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-DQ9wFUPM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudioPage() {
	const { uploads, saved, videos } = useLibrary();
	const toast = useToast();
	const navigate = useNavigate();
	const [title, setTitle] = (0, import_react.useState)("");
	const [creator, setCreator] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)(CATEGORIES[0]);
	const [duration, setDuration] = (0, import_react.useState)("");
	const [synopsis, setSynopsis] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const result = addUpload({
			title,
			creator,
			category,
			duration,
			synopsis
		});
		if (result.error || !result.video) {
			setError(result.error ?? "Could not save that video.");
			return;
		}
		setError("");
		setTitle("");
		setDuration("");
		setSynopsis("");
		toast("Published to this device. It now appears in Trending.");
		navigate({
			to: "/watch/$slug",
			params: { slug: result.video.slug }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "page-intro",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "CREATOR STUDIO"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Publish to your shelf" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This demo keeps uploads, saves, and comments in this browser only. Nothing is sent to a server, and cards stay abstract — add a title and synopsis, not a media file." })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "studio-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "New video" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "title",
							children: "Title"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "title",
							value: title,
							maxLength: 80,
							placeholder: "A quiet evening — creator diary",
							onChange: (event) => setTitle(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "creator",
							children: "Creator"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "creator",
							value: creator,
							maxLength: 40,
							placeholder: "Your studio name",
							onChange: (event) => setCreator(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "category",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "category",
							value: category,
							onChange: (event) => setCategory(event.target.value),
							children: CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "duration",
							children: "Duration"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "duration",
							value: duration,
							inputMode: "numeric",
							placeholder: "08:16",
							onChange: (event) => setDuration(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "synopsis",
							children: "Synopsis"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "synopsis",
							value: synopsis,
							maxLength: 280,
							placeholder: "What will someone understand after watching?",
							onChange: (event) => setSynopsis(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "form-error",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary",
						type: "submit",
						children: "Publish on this device"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stat",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: uploads.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Your uploads" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stat",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: saved.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Saved" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stat",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: videos.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "On the shelf" })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Your uploads" }),
					uploads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "Nothing published from this browser yet."
					}) : uploads.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "upload-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: video.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							video.category,
							" · ",
							video.duration
						] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/watch/$slug",
							params: { slug: video.slug },
							children: "Open"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "icon-text",
							type: "button",
							onClick: () => {
								removeUpload(video.slug);
								toast("Removed from this device.");
							},
							children: "Remove"
						})] })]
					}, video.slug))
				]
			})]
		})]
	});
}
//#endregion
export { StudioPage as component };
