import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useToast } from "./router-D2jjv7p6.mjs";
import { a as addThread, p as loadThreads, r as addReply } from "./library-D9NbDMrz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/community-Cmeuovq9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function whenLabel(at) {
	if (!at) return "Featured";
	const minutes = Math.floor((Date.now() - at) / 6e4);
	if (minutes < 1) return "Just now";
	if (minutes < 60) return `${minutes}m ago`;
	const hours = Math.floor(minutes / 60);
	if (hours < 24) return `${hours}h ago`;
	return `${Math.floor(hours / 24)}d ago`;
}
function CommunityPage() {
	const toast = useToast();
	const [threads, setThreads] = (0, import_react.useState)([]);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [author, setAuthor] = (0, import_react.useState)("Guest");
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [reply, setReply] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function refresh(focus) {
		const next = loadThreads();
		setThreads(next);
		if (focus) setOpenId(focus);
	}
	(0, import_react.useEffect)(() => {
		refresh();
	}, []);
	function onCreate(event) {
		event.preventDefault();
		const result = addThread({
			title,
			body,
			author
		});
		if (result.error) {
			setError(result.error);
			return;
		}
		setError("");
		setTitle("");
		setBody("");
		refresh();
		toast("Thread posted on this device.");
	}
	function onReply(event, threadId) {
		event.preventDefault();
		const result = addReply(threadId, {
			author,
			body: reply
		});
		if (result.error) {
			setError(result.error);
			return;
		}
		setError("");
		setReply("");
		refresh(threadId);
		toast("Reply saved on this device.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-intro",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "COMMUNITY"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Discussions" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A local board for how sets are run. Posts stay on this device." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel",
				onSubmit: onCreate,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Start a thread" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "split-fields",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: author,
								maxLength: 32,
								onChange: (event) => setAuthor(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Title", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: title,
								maxLength: 90,
								placeholder: "What are you asking?",
								onChange: (event) => setTitle(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: ["Post", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: body,
							maxLength: 500,
							placeholder: "Keep it about the work, the set, or the shelf.",
							onChange: (event) => setBody(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "form-error",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary",
						type: "submit",
						children: "Post thread"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stack",
				children: threads.map((thread) => {
					const open = openId === thread.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "panel thread",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "thread-toggle",
							onClick: () => setOpenId(open ? null : thread.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: thread.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
								thread.author,
								" · ",
								whenLabel(thread.at),
								" · ",
								thread.replies.length,
								" ",
								thread.replies.length === 1 ? "reply" : "replies"
							] })] })
						}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "thread-body",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: thread.body }),
								thread.replies.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "comment",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [item.author, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { children: whenLabel(item.at) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.body })]
								}, item.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									className: "comment-form",
									onSubmit: (event) => onReply(event, thread.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										"aria-label": "Reply",
										value: reply,
										maxLength: 400,
										onChange: (event) => setReply(event.target.value)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn primary",
										type: "submit",
										children: "Reply"
									})]
								})
							]
						}) : null]
					}, thread.id);
				})
			})
		]
	});
}
//#endregion
export { CommunityPage as component };
