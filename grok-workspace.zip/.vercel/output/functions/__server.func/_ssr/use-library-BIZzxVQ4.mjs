import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as CATALOG } from "./router-D2jjv7p6.mjs";
import { _ as toggleFollow, c as loadFollows, f as loadSaved, l as loadLikes, m as loadUploads, t as LIBRARY_EVENT, u as loadMemberName, v as toggleLike, y as toggleSaved } from "./library-D9NbDMrz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-library-BIZzxVQ4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useLibrary() {
	const [uploads, setUploads] = (0, import_react.useState)([]);
	const [saved, setSaved] = (0, import_react.useState)([]);
	const [likes, setLikes] = (0, import_react.useState)([]);
	const [follows, setFollows] = (0, import_react.useState)([]);
	const [memberName, setMemberName] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const sync = () => {
			setUploads(loadUploads());
			setSaved(loadSaved());
			setLikes(loadLikes());
			setFollows(loadFollows());
			setMemberName(loadMemberName());
			setReady(true);
		};
		sync();
		window.addEventListener(LIBRARY_EVENT, sync);
		window.addEventListener("storage", sync);
		return () => {
			window.removeEventListener(LIBRARY_EVENT, sync);
			window.removeEventListener("storage", sync);
		};
	}, []);
	return {
		videos: (0, import_react.useMemo)(() => {
			const slugs = new Set(uploads.map((video) => video.slug));
			return [...uploads, ...CATALOG.filter((video) => !slugs.has(video.slug))];
		}, [uploads]),
		uploads,
		saved,
		likes,
		follows,
		memberName,
		ready,
		isSaved: (slug) => saved.includes(slug),
		isLiked: (slug) => likes.includes(slug),
		toggleSaved: (slug) => {
			toggleSaved(slug);
		},
		toggleLike: (slug) => {
			toggleLike(slug);
		},
		toggleFollow: (slug) => {
			toggleFollow(slug);
		}
	};
}
//#endregion
export { useLibrary as t };
