import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as CATEGORIES } from "./router-D2jjv7p6.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-CXCtJ23W.js
var import_jsx_runtime = require_jsx_runtime();
function InsightsPage() {
	const { videos, uploads, saved, likes, follows } = useLibrary();
	const views = videos.reduce((sum, video) => sum + video.viewsNum, 0);
	const counts = CATEGORIES.map((category) => ({
		category,
		count: videos.filter((video) => video.category === category).length
	}));
	const peak = Math.max(1, ...counts.map((row) => row.count));
	const creators = [...new Set(videos.map((video) => video.creator))].length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-intro",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "INSIGHTS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Shelf at a glance" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Counts from the sample catalog plus anything you published on this device." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stat-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: videos.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Videos on the shelf" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: uploads.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Published here" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: creators }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Creator names" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stat-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [Math.round(views / 1e3), "K"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sample views" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: saved.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Saved" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: likes.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Likes" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Top categories" }),
					counts.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bar-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.category }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "bar-track",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "bar-fill",
									style: { width: `${row.count / peak * 100}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: row.count })
						]
					}, row.category)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "section-kicker",
						children: [
							"Following ",
							follows.length,
							" ",
							follows.length === 1 ? "creator" : "creators",
							" on this device."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						className: "btn outline",
						to: "/studio",
						children: "Open Creator Studio"
					})
				]
			})
		]
	});
}
//#endregion
export { InsightsPage as component };
