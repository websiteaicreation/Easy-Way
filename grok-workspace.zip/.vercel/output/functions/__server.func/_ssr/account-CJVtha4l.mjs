import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useCurrentUserState, u as CREATORS } from "./router-D2jjv7p6.mjs";
import { n as VideoCard } from "./video-card-D54OchWJ.mjs";
import { n as UserButton } from "./gates-C0oqvQwR.mjs";
import { o as myLibrary } from "./shelf.functions-C5y8heLN.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-CJVtha4l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountPage() {
	const { videos, saved, likes, uploads, memberName, follows } = useLibrary();
	const { user, isPending } = useCurrentUserState();
	const [accountLikes, setAccountLikes] = (0, import_react.useState)([]);
	const [accountFavorites, setAccountFavorites] = (0, import_react.useState)([]);
	const [subscriptions, setSubscriptions] = (0, import_react.useState)([]);
	const [role, setRole] = (0, import_react.useState)("member");
	const savedVideos = videos.filter((video) => saved.includes(video.slug));
	const likedVideos = videos.filter((video) => likes.includes(video.slug));
	const favoriteVideos = videos.filter((video) => accountFavorites.includes(video.slug));
	const userId = user?.id;
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		myLibrary().then((library) => {
			setRole(library.role);
			setAccountLikes(library.likes);
			setAccountFavorites(library.favorites);
			setSubscriptions(library.subscriptions);
		}).catch(() => {
			setAccountLikes([]);
			setAccountFavorites([]);
		});
	}, [userId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-intro",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "THIS DEVICE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: user?.displayName || memberName || "Your library" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: user ? "Signed-in likes, favorites, and subscriptions are stored in the database." : isPending ? "Checking your session…" : "Sign in to keep likes, favorites, and subscriptions on your account. This device still remembers a local copy." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "action-row",
						children: [
							isPending ? null : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								className: "btn primary",
								to: "/login",
								children: "Sign in"
							}),
							role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								className: "btn ghost",
								to: "/admin",
								children: "Moderation"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								className: "btn ghost",
								to: "/studio",
								children: "Creator Studio"
							})
						]
					})
				]
			}),
			user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Account favorites" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "section-kicker",
					children: [
						accountFavorites.length,
						" saved · ",
						accountLikes.length,
						" likes"
					]
				})]
			}), favoriteVideos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "video-grid",
				children: favoriteVideos.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video }, video.slug))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "empty",
				children: "Nothing in your account favorites yet."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Subscriptions" }), subscriptions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "section-kicker",
					children: "Follow a creator while signed in to subscribe."
				}) : subscriptions.map((slug) => {
					const creator = CREATORS.find((item) => item.slug === slug);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "upload-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: creator?.name ?? slug }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "section-kicker",
							children: creator?.place ?? "Creator"
						})] }), creator ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "btn ghost",
							to: "/creator/$slug",
							params: { slug: creator.slug },
							children: "Open"
						}) : null]
					}, slug);
				})]
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Saved" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "section-kicker",
					children: savedVideos.length
				})]
			}), savedVideos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "video-grid",
				children: savedVideos.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video }, video.slug))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "empty",
				children: "Nothing saved yet. Use Save on a video."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Liked" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "section-kicker",
					children: likedVideos.length
				})]
			}), likedVideos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "video-grid",
				children: likedVideos.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video }, video.slug))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "empty",
				children: "No likes yet."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Published here" }),
					uploads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "Studio uploads will show up in this list."
					}) : null,
					uploads.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "upload-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: video.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "section-kicker",
							children: [
								video.creator,
								" · ",
								video.category
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "btn ghost",
							to: "/watch/$slug",
							params: { slug: video.slug },
							children: "Open"
						})]
					}, video.slug)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "section-kicker",
						children: [
							"Following ",
							follows.length,
							"."
						]
					})
				]
			})
		]
	});
}
//#endregion
export { AccountPage as component };
