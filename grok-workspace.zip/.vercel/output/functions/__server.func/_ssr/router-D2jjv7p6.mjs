import { o as __toESM } from "../_runtime.mjs";
import { C as useRouter, S as useNavigate, Z as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, w as require_jsx_runtime, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as __exportAll } from "./ssr.mjs";
import { L as string, N as number, P as object, R as union, j as literal } from "../_libs/@better-auth/core+[...].mjs";
import { t as authClient } from "./client-1vAx-gM_.mjs";
import { n as auth } from "./server-C2BC5iFO.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { E as BadgeCheck, S as ChevronDown, T as Camera, _ as Menu, a as TriangleAlert, d as Search, f as Scissors, g as Newspaper, i as Tv, l as Shield, m as Play, n as Users, o as ThumbsUp, p as Plus, r as UserRound, s as Star, t as X, w as ChartColumn, x as Clapperboard, y as Flame } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-F_GbdUyQ.js
var CATEGORIES = [
	"Lesbian",
	"18-25",
	"MILF",
	"Popular With Women",
	"Anal",
	"Threesome",
	"Mature",
	"Hentai",
	"Ebony",
	"Japanese"
];
var CREATORS = [
	{
		slug: "mila-studio",
		name: "Mila Studio",
		place: "Marrakech",
		bio: "Diary films about city light, riads, and the rooms people actually live in.",
		art: "amber"
	},
	{
		slug: "northlight",
		name: "Northlight",
		place: "Montreal",
		bio: "Illustrated loops and paced clips. The set comes down before anyone calls it finished.",
		art: "rose"
	},
	{
		slug: "studio-june",
		name: "Studio June",
		place: "Tokyo",
		bio: "Short films about affection, distance, and the conversations that happen after midnight.",
		art: "violet"
	},
	{
		slug: "lena-moves",
		name: "Lena Moves",
		place: "Austin",
		bio: "Shorties and slow mornings, filmed for people who want the quiet version.",
		art: "green"
	},
	{
		slug: "easy-way-originals",
		name: "Easy Way Originals",
		place: "Remote",
		bio: "Interviews and photo sets with creators who publish for adult audiences.",
		art: "blue"
	},
	{
		slug: "the-sunday-set",
		name: "The Sunday Set",
		place: "London",
		bio: "Small-cast nights. Three people, one table, and a rule that everyone speaks first.",
		art: "gold"
	}
];
var CATALOG = [
	{
		slug: "a-weekend-in-the-city-creator-diary",
		title: "A Weekend in the City — Together",
		creator: "Mila Studio",
		category: "Lesbian",
		views: "248K",
		viewsNum: 248e3,
		duration: "12:48",
		durationSec: 768,
		time: 6,
		art: "amber",
		featured: true,
		region: "morocco",
		synopsis: "Two women share a Saturday market, a late train, and one apartment. A diary about pace, not spectacle."
	},
	{
		slug: "behind-the-scenes-a-creative-day",
		title: "Slow, and On Her Terms",
		creator: "Northlight",
		category: "Anal",
		views: "192K",
		viewsNum: 192e3,
		duration: "08:16",
		durationSec: 496,
		time: 5,
		art: "rose",
		kind: "clip",
		synopsis: "A paced clip about checking in, slowing down, and stopping the moment someone asks. Consent stays in the frame."
	},
	{
		slug: "a-little-romance-short-film",
		title: "After Class, Before Midnight",
		creator: "Studio June",
		category: "18-25",
		views: "184K",
		viewsNum: 184e3,
		duration: "18:03",
		durationSec: 1083,
		time: 4,
		art: "violet",
		featured: true,
		synopsis: "Two adults share a booth, a missed train, and one honest conversation. A short film staged like a letter."
	},
	{
		slug: "morning-movement-and-wellness",
		title: "The Morning She Stayed",
		creator: "Lena Moves",
		category: "Popular With Women",
		views: "96K",
		viewsNum: 96e3,
		duration: "09:42",
		durationSec: 582,
		time: 3,
		art: "green",
		synopsis: "A slow morning between partners: light, breath, and no rush to leave the room. Built for women who want the quiet version."
	},
	{
		slug: "the-after-hours-interview",
		title: "Unhurried — After Hours",
		creator: "Easy Way Originals",
		category: "Mature",
		views: "87K",
		viewsNum: 87e3,
		duration: "22:11",
		durationSec: 1331,
		time: 2,
		art: "blue",
		featured: true,
		synopsis: "A long conversation with a creator who publishes on her own clock. Boundaries, schedules, and what she wishes she knew earlier."
	},
	{
		slug: "two-truths-and-a-story",
		title: "Three at the Table",
		creator: "The Sunday Set",
		category: "Threesome",
		views: "76K",
		viewsNum: 76e3,
		duration: "06:35",
		durationSec: 395,
		time: 1,
		art: "gold",
		synopsis: "Three adults decide, out loud, what they want from the night. Nobody is the punchline."
	},
	{
		slug: "a-quiet-evening-creator-diary",
		title: "The Evening She Kept",
		creator: "Mila Studio",
		category: "MILF",
		views: "65K",
		viewsNum: 65e3,
		duration: "14:20",
		durationSec: 860,
		time: 7,
		art: "rose",
		featured: true,
		synopsis: "Cooking for one, notes for tomorrow’s shoot, and a window left open. An older creator’s evening, kept close."
	},
	{
		slug: "making-the-set-studio-notes",
		title: "Ink After Dark",
		creator: "Northlight",
		category: "Hentai",
		views: "58K",
		viewsNum: 58e3,
		duration: "04:12",
		durationSec: 252,
		time: 8,
		art: "violet",
		kind: "clip",
		synopsis: "An illustrated short. Abstract frames and ink, no live actors, cut like a studio note."
	},
	{
		slug: "a-sunday-reset-home-and-habits",
		title: "Golden Hour in the Riad",
		creator: "Mila Studio",
		category: "Ebony",
		views: "51K",
		viewsNum: 51e3,
		duration: "07:52",
		durationSec: 472,
		time: 9,
		art: "amber",
		featured: true,
		region: "morocco",
		synopsis: "Studio light in a Marrakech riad. A portrait session held at the warmest hour of the day."
	},
	{
		slug: "the-art-of-the-short-film",
		title: "Tokyo, After the Train",
		creator: "Studio June",
		category: "Japanese",
		views: "43K",
		viewsNum: 43e3,
		duration: "16:24",
		durationSec: 984,
		time: 10,
		art: "rose",
		synopsis: "June breaks down blocking, silence, and why the film ends one line earlier than expected."
	},
	{
		slug: "stretch-breathe-recharge",
		title: "Riad Glow",
		creator: "Lena Moves",
		category: "18-25",
		views: "39K",
		viewsNum: 39e3,
		duration: "00:46",
		durationSec: 46,
		time: 11,
		art: "green",
		kind: "short",
		region: "morocco",
		synopsis: "A shorty from a riad courtyard. One look back, then the light changes."
	},
	{
		slug: "creator-q-and-a-getting-started",
		title: "Still, Set One",
		creator: "Easy Way Originals",
		category: "Ebony",
		views: "31K",
		viewsNum: 31e3,
		duration: "00:12",
		durationSec: 12,
		time: 12,
		art: "blue",
		kind: "photo",
		synopsis: "A photo set. One still, held. No clip attached — the card is the picture."
	},
	{
		slug: "atlas-light-clip",
		title: "Atlas Light",
		creator: "Mila Studio",
		category: "MILF",
		views: "44K",
		viewsNum: 44e3,
		duration: "03:20",
		durationSec: 200,
		time: 13,
		art: "gold",
		kind: "clip",
		region: "morocco",
		synopsis: "A three-minute clip shot against the High Atlas at dusk. Close, calm, and fully agreed."
	},
	{
		slug: "three-count-shorty",
		title: "Three Count",
		creator: "The Sunday Set",
		category: "Threesome",
		views: "28K",
		viewsNum: 28e3,
		duration: "00:38",
		durationSec: 38,
		time: 14,
		art: "gold",
		kind: "short",
		synopsis: "A shorty: three people, one countdown, and a laugh before anyone moves."
	},
	{
		slug: "amber-loop",
		title: "Amber Loop",
		creator: "Lena Moves",
		category: "Popular With Women",
		views: "22K",
		viewsNum: 22e3,
		duration: "00:06",
		durationSec: 6,
		time: 15,
		art: "amber",
		kind: "gif",
		region: "morocco",
		synopsis: "A looping GIF. Warm light, a turn of the shoulder, then it starts again."
	},
	{
		slug: "ink-loop",
		title: "Ink Loop",
		creator: "Northlight",
		category: "Hentai",
		views: "19K",
		viewsNum: 19e3,
		duration: "00:08",
		durationSec: 8,
		time: 16,
		art: "violet",
		kind: "gif",
		synopsis: "An ink loop. Line, blush, line. Illustrated only."
	},
	{
		slug: "window-light-still",
		title: "Window Light Still",
		creator: "Studio June",
		category: "Japanese",
		views: "17K",
		viewsNum: 17e3,
		duration: "00:10",
		durationSec: 10,
		time: 17,
		art: "rose",
		kind: "photo",
		synopsis: "A single window-light still from the Tokyo set. Nothing moves."
	},
	{
		slug: "marrakech-heat",
		title: "Marrakech Heat",
		creator: "Mila Studio",
		category: "Lesbian",
		views: "121K",
		viewsNum: 121e3,
		duration: "11:05",
		durationSec: 665,
		time: 18,
		art: "rose",
		featured: true,
		region: "morocco",
		synopsis: "Hottest in Morocco this week. A riad, two women, and the fan that never quite keeps up."
	}
];
var SEED_COMMENTS = {
	"a-weekend-in-the-city-creator-diary": [{
		user: "Nora",
		text: "The market audio feels close without being noisy. Lovely pacing."
	}, {
		user: "Evan",
		text: "That train window shot is the one I keep rewinding."
	}],
	"a-little-romance-short-film": [{
		user: "Hana",
		text: "They let the silence sit. More films should trust that."
	}, {
		user: "Chris",
		text: "The booth lighting is doing half the acting. In a good way."
	}],
	"the-after-hours-interview": [{
		user: "Priya",
		text: "The section on schedules is the most useful thing I have watched this month."
	}],
	"morning-movement-and-wellness": [{
		user: "Jules",
		text: "Did this with the sound low. The quiet is exactly long enough."
	}]
};
var ART_FOR = {
	Lesbian: "rose",
	"18-25": "amber",
	MILF: "gold",
	"Popular With Women": "violet",
	Anal: "blue",
	Threesome: "green",
	Mature: "amber",
	Hentai: "violet",
	Ebony: "gold",
	Japanese: "rose"
};
function artForCategory(category) {
	return ART_FOR[category];
}
function getCatalogVideo(slug) {
	return CATALOG.find((video) => video.slug === slug);
}
function creatorProfile(name) {
	return CREATORS.find((creator) => creator.name === name);
}
function getCreator(slug) {
	return CREATORS.find((creator) => creator.slug === slug);
}
function slugify(title) {
	return title.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 72) || "video";
}
function parseDuration(value) {
	const match = /^(\d{1,3}):([0-5]\d)$/.exec(value.trim());
	if (!match) return null;
	const minutes = Number(match[1]);
	const seconds = Number(match[2]);
	if (minutes > 180) return null;
	if (minutes === 0 && seconds === 0) return null;
	return minutes * 60 + seconds;
}
function formatClock(total) {
	const safe = Math.max(0, Math.floor(total));
	const minutes = Math.floor(safe / 60);
	const seconds = safe % 60;
	return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}
function chipLabel(category) {
	if (category === "All") return "All videos";
	if (category === "Saved") return "Playlists";
	return category;
}
function relatedVideos(videos, current, limit = 5) {
	const others = videos.filter((video) => video.slug !== current.slug);
	const close = others.filter((video) => video.category === current.category || video.creator === current.creator);
	const rest = others.filter((video) => !close.includes(video));
	return [...close, ...rest].slice(0, limit);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/browse-Bbv3IGlq.js
function sortFor(lane) {
	if (lane === "shorties" || lane === "clips") return "short";
	if (lane === "recommended") return "newest";
	return "popular";
}
var useBrowse = create((set) => ({
	query: "",
	category: "All",
	lane: "all",
	sort: "popular",
	page: 1,
	setQuery: (query) => set({
		query,
		page: 1
	}),
	setCategory: (category) => set({
		category,
		lane: "all",
		page: 1
	}),
	setLane: (lane) => set({
		lane,
		category: "All",
		page: 1,
		sort: sortFor(lane)
	}),
	setSort: (sort) => set({
		sort,
		page: 1
	}),
	setPage: (page) => set({ page })
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-D2jjv7p6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function CategoryDrawer({ open, onClose, onToast }) {
	const [modelsOpen, setModelsOpen] = (0, import_react.useState)(false);
	const [channelsOpen, setChannelsOpen] = (0, import_react.useState)(false);
	const [categoriesOpen, setCategoriesOpen] = (0, import_react.useState)(true);
	const [communityOpen, setCommunityOpen] = (0, import_react.useState)(false);
	const category = useBrowse((state) => state.category);
	const lane = useBrowse((state) => state.lane);
	const setCategory = useBrowse((state) => state.setCategory);
	const setLane = useBrowse((state) => state.setLane);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const navigate = useNavigate();
	const [top, setTop] = (0, import_react.useState)(92);
	(0, import_react.useEffect)(() => {
		function place() {
			const bar = document.querySelector(".topbar");
			if (!bar) return;
			setTop(bar.getBoundingClientRect().bottom);
		}
		place();
		window.addEventListener("resize", place);
		window.addEventListener("scroll", place, { passive: true });
		return () => {
			window.removeEventListener("resize", place);
			window.removeEventListener("scroll", place);
		};
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onKey(event) {
			if (event.key === "Escape") onClose();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	function go(apply) {
		apply();
		onClose();
		if (pathname !== "/") {
			navigate({
				to: "/",
				hash: "discover"
			});
			return;
		}
		document.getElementById("discover")?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}
	function pickLane(next) {
		go(() => setLane(next));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: open ? "drawer-root open" : "drawer-root",
		hidden: !open,
		style: { top },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "drawer-backdrop",
			"aria-label": "Close menu",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "drawer",
			"aria-label": "Categories",
			"aria-hidden": !open,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					className: "drawer-program",
					to: "/studio",
					onClick: onClose,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Join the Easy Way Creator Program" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "featured" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("featured"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Featured Videos" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "clips" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("clips"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scissors, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Clips" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "shorties" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("shorties"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shorties" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "recommended" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("recommended"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Recommended Videos" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "morocco" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("morocco"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { size: 18 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hottest In Morocco" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
							className: "drawer-hot",
							size: 14,
							fill: "currentColor",
							"aria-hidden": "true"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "drawer-row",
					"aria-expanded": modelsOpen,
					onClick: () => setModelsOpen((value) => !value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { size: 18 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pornstars & Models" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							className: modelsOpen ? "chev open" : "chev",
							size: 18
						})
					]
				}),
				modelsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "drawer-sub",
					children: CREATORS.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						className: "drawer-row sub",
						to: "/creator/$slug",
						params: { slug: creator.slug },
						onClick: onClose,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `model-dot art-${creator.art}`,
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: creator.name })]
					}, creator.slug))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "drawer-row",
					"aria-expanded": channelsOpen,
					onClick: () => setChannelsOpen((value) => !value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tv, { size: 18 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Channels" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							className: channelsOpen ? "chev open" : "chev",
							size: 18
						})
					]
				}),
				channelsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "drawer-sub",
					children: CREATORS.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						className: "drawer-row sub",
						to: "/creator/$slug",
						params: { slug: creator.slug },
						onClick: onClose,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tv, { size: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: creator.name })]
					}, creator.slug))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "drawer-row",
					"aria-expanded": categoriesOpen,
					onClick: () => setCategoriesOpen((value) => !value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 18 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Top Categories" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							className: categoriesOpen ? "chev open" : "chev",
							size: 18
						})
					]
				}),
				categoriesOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "drawer-sub",
					children: [CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: category === item && lane === "all" ? "drawer-row sub active" : "drawer-row sub",
						onClick: () => go(() => setCategory(item)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
					}, item)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "drawer-all",
						onClick: () => {
							setCategory("All");
							onClose();
							if (pathname !== "/") {
								navigate({
									to: "/",
									hash: "categories"
								});
								return;
							}
							document.getElementById("categories")?.scrollIntoView({
								behavior: "smooth",
								block: "start"
							});
						},
						children: "All Categories"
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: category === "Saved" ? "drawer-row active" : "drawer-row",
					onClick: () => go(() => setCategory("Saved")),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Playlists" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "gifs" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("gifs"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "gif-mark",
						children: "GIF"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Porn GIFs" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: lane === "photos" ? "drawer-row active" : "drawer-row",
					onClick: () => pickLane("photos"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Photos" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "drawer-row",
					"aria-expanded": communityOpen,
					onClick: () => setCommunityOpen((value) => !value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { size: 18 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Community" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							className: communityOpen ? "chev open" : "chev",
							size: 18
						})
					]
				}),
				communityOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "drawer-sub",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "drawer-row sub",
							to: "/safety",
							hash: "standards",
							onClick: onClose,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Guidelines" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "drawer-row sub",
							to: "/safety",
							hash: "report",
							onClick: onClose,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Report content" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "drawer-row sub",
							to: "/community",
							onClick: onClose,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Discussions" })
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "drawer-cta",
					to: "/membership",
					onClick: onClose,
					children: "Get Full Easy Way Membership"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "drawer-grid",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/safety",
							className: "drawer-mini",
							onClick: onClose,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Trust & Safety" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/studio",
							className: "drawer-mini",
							onClick: onClose,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Studio" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/blog",
							className: "drawer-mini",
							onClick: onClose,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newspaper, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Blog" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/insights",
							className: "drawer-mini",
							onClick: onClose,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Insights" })]
						})
					]
				})
			]
		})]
	});
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var ToastContext = (0, import_react.createContext)(() => {});
function useToast() {
	return (0, import_react.useContext)(ToastContext);
}
var AGE_KEY = "afterdark18";
function Shell({ children }) {
	const [phase, setPhase] = (0, import_react.useState)("ask");
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)(true);
	const [toast, setToast] = (0, import_react.useState)("");
	const [toastOn, setToastOn] = (0, import_react.useState)(false);
	const query = useBrowse((state) => state.query);
	const setQuery = useBrowse((state) => state.setQuery);
	const [draft, setDraft] = (0, import_react.useState)(query);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	(0, import_react.useEffect)(() => {
		setDraft(query);
	}, [query]);
	(0, import_react.useEffect)(() => {
		try {
			if (localStorage.getItem(AGE_KEY) === "yes" || document.documentElement.dataset.ad === "in") {
				document.documentElement.dataset.ad = "in";
				setPhase("in");
			}
		} catch {
			if (document.documentElement.dataset.ad === "in") setPhase("in");
		}
	}, []);
	(0, import_react.useEffect)(() => {
		setMenuOpen(false);
	}, [pathname]);
	function showToast(message) {
		setToast(message);
		setToastOn(true);
		window.setTimeout(() => setToastOn(false), 2600);
	}
	function enter() {
		document.documentElement.dataset.ad = "in";
		try {
			localStorage.setItem(AGE_KEY, "yes");
		} catch {}
		setPhase("in");
	}
	function onSearch(event) {
		event.preventDefault();
		setQuery(draft.trim());
		setMenuOpen(false);
		if (pathname !== "/") {
			navigate({
				to: "/",
				hash: "discover"
			});
			return;
		}
		document.getElementById("discover")?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToastContext.Provider, {
		value: showToast,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-frame",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "utilitybar",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/studio",
								children: "CREATOR TOOLS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/blog",
								children: "STORIES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/community",
								children: "COMMUNITY"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/insights",
								children: "INSIGHTS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/safety",
								children: "TRUST & SAFETY"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "language",
								children: "EN"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "topbar",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "icon-btn",
								type: "button",
								"aria-label": "Toggle menu",
								"aria-expanded": menuOpen,
								onClick: () => setMenuOpen((open) => !open),
								children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 20 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								className: "brand",
								to: "/",
								activeOptions: {
									exact: true,
									includeHash: false
								},
								children: ["Easy ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Way" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "search",
								onSubmit: onSearch,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: draft,
									onChange: (event) => setDraft(event.target.value),
									placeholder: "Search videos and creators",
									"aria-label": "Search videos and creators"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									"aria-label": "Search",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 18 })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								className: "header-action",
								to: "/studio",
								title: "Creator studio",
								"aria-label": "Creator studio",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 22 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								className: "header-action",
								to: isPending || user ? "/account" : "/login",
								title: user ? "Your library" : "Sign in",
								"aria-label": user ? "Your library" : "Sign in",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { size: 20 })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "mainnav",
						id: "mainNav",
						"aria-label": "Primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								activeOptions: {
									exact: true,
									includeHash: true
								},
								children: "HOME"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "discover",
								children: "VIDEOS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMenuOpen(true),
								children: "CATEGORIES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "creators",
								children: "CREATORS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/studio",
								activeOptions: { exact: true },
								children: "CREATOR STUDIO"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/safety",
								activeOptions: { exact: true },
								children: "TRUST & SAFETY"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryDrawer, {
						open: menuOpen,
						onClose: () => setMenuOpen(false),
						onToast: showToast
					}),
					pathname === "/" && notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "container",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "notice",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"You are browsing Easy Way in English.",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/safety",
									hash: "standards",
									children: "Learn about our community."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Dismiss notice",
								onClick: () => setNotice(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "page",
						children
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "site-footer",
						id: "about",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "footer-brand",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									className: "brand",
									to: "/",
									children: ["Easy ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Way" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Adult-only discovery demo. Built around consent, safety, and creator rights." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Explore" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									hash: "discover",
									children: "Trending"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMenuOpen(true),
									children: "Categories"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									hash: "creators",
									children: "Creators"
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Safety" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/safety",
									children: "Trust & Safety"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/safety",
									hash: "report",
									children: "Report content"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/safety",
									hash: "copyright",
									children: "Copyright & takedowns"
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Information" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/safety",
									hash: "privacy",
									children: "Privacy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/safety",
									hash: "terms",
									children: "Terms"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "mailto:hello@example.com",
									children: "Contact"
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "copyright",
								children: "© 2026 Easy Way. Demo concept — sample cards use abstract art, not explicit media. Replace contact details and policies before any real launch."
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "gate",
				hidden: phase === "in",
				children: phase === "deny" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "gate-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Access denied" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You must be at least 18 to enter this demo." })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "gate-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand large",
							children: ["Easy ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Way" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "ADULTS ONLY · 18+"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Are you 18 or older?" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This demo is intended only for adults. By entering, you confirm that you are at least 18 and that viewing adult-oriented material is legal where you live." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn primary",
							type: "button",
							"data-age-enter": true,
							onClick: enter,
							children: "I am 18 or older — Enter"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn ghost",
							type: "button",
							onClick: () => setPhase("deny"),
							children: "I am under 18 — Exit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Demo interface only. Sample cards use abstract placeholders, not explicit media." })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: toastOn ? "toast show" : "toast",
				role: "status",
				children: toast
			})
		]
	});
}
var styles_default = "/assets/styles-BEZzC6zN.css";
var AGE_BOOT = `(function(){try{if(localStorage.getItem("afterdark18")==="yes")document.documentElement.dataset.ad="in"}catch(e){}function pass(e){var n=e.target&&e.target.closest&&e.target.closest("[data-age-enter]");if(!n)return;document.documentElement.dataset.ad="in";try{localStorage.setItem("afterdark18","yes")}catch(err){}}document.addEventListener("pointerup",pass,true);document.addEventListener("click",pass,true);})();`;
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: "Easy Way — Discover" },
			{
				name: "description",
				content: "Easy Way — an adult-only creator video discovery demo."
			},
			{
				name: "theme-color",
				content: "#080808"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: AGE_BOOT } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$12 = () => import("./routes-B0Vg2Fmo.mjs");
var Route$13 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("../_-C_cUvp0V.mjs");
var Route$12 = createFileRoute("/$")({
	head: () => ({ meta: [{ title: "Page not found — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./account-CJVtha4l.mjs");
var Route$11 = createFileRoute("/account")({
	head: () => ({ meta: [{ title: "Your library — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./admin-zBl8wivH.mjs");
var Route$10 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Moderation — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./blog-CU8bOLDP.mjs");
var Route$9 = createFileRoute("/blog")({
	head: () => ({ meta: [{ title: "Stories — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./community-Cmeuovq9.mjs");
var Route$8 = createFileRoute("/community")({
	head: () => ({ meta: [{ title: "Community — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./insights-CXCtJ23W.mjs");
var Route$7 = createFileRoute("/insights")({
	head: () => ({ meta: [{ title: "Insights — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./login-ChvyRfza.mjs");
var Route$6 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "Sign in — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./membership-BEc_Asbn.mjs");
var Route$5 = createFileRoute("/membership")({
	head: () => ({ meta: [{ title: "Membership — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./safety-BerwT-Cz.mjs");
var Route$4 = createFileRoute("/safety")({
	head: () => ({ meta: [{ title: "Trust & Safety — Easy Way" }, {
		name: "description",
		content: "Community standards, reporting, privacy, and terms for the Easy Way demo."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./studio-DQ9wFUPM.mjs");
var Route$3 = createFileRoute("/studio")({
	head: () => ({ meta: [{ title: "Creator studio — Easy Way" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./creator._slug-B7pgRaEt.mjs");
var Route$2 = createFileRoute("/creator/$slug")({
	head: ({ params }) => {
		const creator = getCreator(params.slug);
		return { meta: [{ title: creator ? `${creator.name} — Easy Way` : "Creator — Easy Way" }] };
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./watch._slug-GuzPEVym.mjs");
var Route$1 = createFileRoute("/watch/$slug")({
	head: ({ params }) => {
		const video = getCatalogVideo(params.slug);
		return { meta: [{ title: video ? `${video.title} — Easy Way` : "Watch — Easy Way" }] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var Route = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var rootRouteChildren = {
	IndexRoute: Route$13.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$14
	}),
	SplatRoute: Route$12.update({
		id: "/$",
		path: "/$",
		getParentRoute: () => Route$14
	}),
	AccountRoute: Route$11.update({
		id: "/account",
		path: "/account",
		getParentRoute: () => Route$14
	}),
	AdminRoute: Route$10.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$14
	}),
	BlogRoute: Route$9.update({
		id: "/blog",
		path: "/blog",
		getParentRoute: () => Route$14
	}),
	CommunityRoute: Route$8.update({
		id: "/community",
		path: "/community",
		getParentRoute: () => Route$14
	}),
	InsightsRoute: Route$7.update({
		id: "/insights",
		path: "/insights",
		getParentRoute: () => Route$14
	}),
	LoginRoute: Route$6.update({
		id: "/login",
		path: "/login",
		getParentRoute: () => Route$14
	}),
	MembershipRoute: Route$5.update({
		id: "/membership",
		path: "/membership",
		getParentRoute: () => Route$14
	}),
	SafetyRoute: Route$4.update({
		id: "/safety",
		path: "/safety",
		getParentRoute: () => Route$14
	}),
	StudioRoute: Route$3.update({
		id: "/studio",
		path: "/studio",
		getParentRoute: () => Route$14
	}),
	CreatorSlugRoute: Route$2.update({
		id: "/creator/$slug",
		path: "/creator/$slug",
		getParentRoute: () => Route$14
	}),
	WatchSlugRoute: Route$1.update({
		id: "/watch/$slug",
		path: "/watch/$slug",
		getParentRoute: () => Route$14
	}),
	ApiAuthSplatRoute: Route.update({
		id: "/api/auth/$",
		path: "/api/auth/$",
		getParentRoute: () => Route$14
	})
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { getCreator as _, useCurrentUser as a, slugify as b, CATALOG as c, SEED_COMMENTS as d, artForCategory as f, getCatalogVideo as g, formatClock as h, useToast as i, CATEGORIES as l, creatorProfile as m, Route$1 as n, useCurrentUserState as o, chipLabel as p, Route$2 as r, useBrowse as s, router_exports as t, CREATORS as u, parseDuration as v, relatedVideos as y };
