import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-BKLl0ALZ.mjs";
import { t as authMiddleware } from "./middleware-CAK7_l_2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shelf.functions-DmsiGWIB.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function ensureProfile(sql, userId) {
	await sql`
    insert into profiles (user_id, display_name)
    values (${userId}, ${(await sql`select name from "user" where id = ${userId}`)[0]?.name ?? "Member"})
    on conflict (user_id) do nothing
  `;
}
async function roleFor(sql, userId) {
	await ensureProfile(sql, userId);
	return (await sql`select role from profiles where user_id = ${userId}`)[0]?.role ?? "member";
}
async function videoId(sql, slug) {
	return (await sql`select id from videos where slug = ${slug}`)[0]?.id ?? null;
}
var REACTION = /* @__PURE__ */ new Set(["like", "favorite"]);
var REPORT_STATUS = /* @__PURE__ */ new Set([
	"reviewed",
	"dismissed",
	"removed"
]);
var VERIFY_STATUS = /* @__PURE__ */ new Set(["verified", "rejected"]);
var myLibrary_createServerFn_handler = createServerRpc({
	id: "28406c582cdb9a8f5f0282215ac8678dc7f82c1aecef4b7006daae2efb6a1ed3",
	name: "myLibrary",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => myLibrary.__executeServer(opts));
var myLibrary = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(myLibrary_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const role = await roleFor(sql, context.userId);
	const likes = await sql`
      select v.slug from likes l
      join videos v on v.id = l.video_id
      where l.user_id = ${context.userId}
    `;
	const favorites = await sql`
      select v.slug from favorites f
      join videos v on v.id = f.video_id
      where f.user_id = ${context.userId}
    `;
	const subscriptions = await sql`
      select c.slug from subscriptions s
      join creators c on c.id = s.creator_id
      where s.user_id = ${context.userId}
    `;
	return {
		role,
		likes: likes.map((row) => row.slug),
		favorites: favorites.map((row) => row.slug),
		subscriptions: subscriptions.map((row) => row.slug)
	};
});
var setReaction_createServerFn_handler = createServerRpc({
	id: "c3ebcc6df956902608e0c0afbeed8a493b0557c1bb019d4037d951cd3626c447",
	name: "setReaction",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => setReaction.__executeServer(opts));
var setReaction = createServerFn({ method: "POST" }).validator((input) => {
	if (!REACTION.has(input.kind) || typeof input.slug !== "string" || typeof input.on !== "boolean") throw new Error("Invalid reaction.");
	return {
		slug: input.slug,
		kind: input.kind,
		on: input.on
	};
}).middleware([authMiddleware]).handler(setReaction_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const id = await videoId(sql, data.slug);
	if (!id) return {
		ok: false,
		error: "That video is not in the library."
	};
	if (data.kind === "like") {
		if (data.on) await sql`
          insert into likes (user_id, video_id) values (${context.userId}, ${id})
          on conflict do nothing
        `;
		else await sql`delete from likes where user_id = ${context.userId} and video_id = ${id}`;
	} else if (data.kind === "favorite") {
		if (data.on) await sql`
          insert into favorites (user_id, video_id) values (${context.userId}, ${id})
          on conflict do nothing
        `;
		else await sql`delete from favorites where user_id = ${context.userId} and video_id = ${id}`;
	} else return {
		ok: false,
		error: "Unknown reaction."
	};
	return { ok: true };
});
var setSubscription_createServerFn_handler = createServerRpc({
	id: "87c0231719693d92f2ea3e533663cb21ffda35029ebadf1618305d09eb5a7a5d",
	name: "setSubscription",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => setSubscription.__executeServer(opts));
var setSubscription = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(setSubscription_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const id = (await sql`select id from creators where slug = ${data.slug}`)[0]?.id;
	if (!id) return {
		ok: false,
		error: "That creator is not in the library."
	};
	if (data.on) await sql`
        insert into subscriptions (user_id, creator_id)
        values (${context.userId}, ${id})
        on conflict do nothing
      `;
	else await sql`delete from subscriptions where user_id = ${context.userId} and creator_id = ${id}`;
	return { ok: true };
});
var listDbComments_createServerFn_handler = createServerRpc({
	id: "2eea7e92cbbb588779dae2819e4cfb2a5d0531e7eb0eca75620f0e482baa1372",
	name: "listDbComments",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => listDbComments.__executeServer(opts));
var listDbComments = createServerFn({ method: "GET" }).validator((slug) => slug).handler(listDbComments_createServerFn_handler, async ({ data: slug }) => {
	return (await getSql())`
      select c.id, coalesce(p.display_name, 'Member') as user, c.body, c.created_at::text as at
      from comments c
      join videos v on v.id = c.video_id
      left join profiles p on p.user_id = c.user_id
      where v.slug = ${slug}
      order by c.created_at desc
      limit 50
    `;
});
var addDbComment_createServerFn_handler = createServerRpc({
	id: "77d1bfae8e733aecc6468b60111b696523f4ffd3b8c0619c4ed35e216b3dc291",
	name: "addDbComment",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => addDbComment.__executeServer(opts));
var addDbComment = createServerFn({ method: "POST" }).validator((input) => ({
	slug: input.slug,
	body: input.body.trim()
})).middleware([authMiddleware]).handler(addDbComment_createServerFn_handler, async ({ context, data }) => {
	if (data.body.length < 2) return {
		ok: false,
		error: "Write a comment first."
	};
	if (data.body.length > 400) return {
		ok: false,
		error: "Comments stay under 400 characters."
	};
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const id = await videoId(sql, data.slug);
	if (!id) return {
		ok: false,
		error: "That video is not in the library."
	};
	await sql`
      insert into comments (user_id, video_id, body)
      values (${context.userId}, ${id}, ${data.body})
    `;
	return { ok: true };
});
var addDbReport_createServerFn_handler = createServerRpc({
	id: "eb950e5f38c0356097c6e1c099ee8f10d7696a6ecb799415432d838c7da9c8e5",
	name: "addDbReport",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => addDbReport.__executeServer(opts));
var addDbReport = createServerFn({ method: "POST" }).validator((input) => ({
	slug: input.slug.trim(),
	target: input.target.trim().slice(0, 120),
	reason: input.reason.trim(),
	details: input.details.trim()
})).middleware([authMiddleware]).handler(addDbReport_createServerFn_handler, async ({ context, data }) => {
	if (!data.reason) return {
		ok: false,
		error: "Choose a reason."
	};
	if (data.target.length < 2) return {
		ok: false,
		error: "Say what you are reporting."
	};
	if (data.details.length < 8) return {
		ok: false,
		error: "Add a few details so a moderator could act."
	};
	if (data.details.length > 500) return {
		ok: false,
		error: "Keep the note under 500 characters."
	};
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const id = data.slug ? await videoId(sql, data.slug) : null;
	await sql`
      insert into reports (user_id, video_id, target, reason, details)
      values (${context.userId}, ${id}, ${data.target}, ${data.reason}, ${data.details})
    `;
	return { ok: true };
});
var adminQueue_createServerFn_handler = createServerRpc({
	id: "d372880cbd083f8ad60e09f2b4b87d2867b5afd3da81658242ee79c7d12f6aba",
	name: "adminQueue",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => adminQueue.__executeServer(opts));
var adminQueue = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminQueue_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	if (await roleFor(sql, context.userId) !== "admin") return {
		ok: false,
		error: "Administrators only."
	};
	return {
		ok: true,
		reports: await sql`
      select id, target, reason, details, status, created_at::text as at
      from reports
      order by created_at desc
      limit 40
    `,
		creators: await sql`
      select id, name, slug, verified from creators order by name
    `
	};
});
var moderateReport_createServerFn_handler = createServerRpc({
	id: "0f283c2797580d1afd8b764ed86695a8b74124d6abebcac5856b3d92c8b59e42",
	name: "moderateReport",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => moderateReport.__executeServer(opts));
var moderateReport = createServerFn({ method: "POST" }).validator((input) => {
	if (!REPORT_STATUS.has(input.action) || typeof input.id !== "number") throw new Error("Invalid moderation action.");
	return {
		id: input.id,
		action: input.action,
		note: String(input.note ?? "")
	};
}).middleware([authMiddleware]).handler(moderateReport_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (await roleFor(sql, context.userId) !== "admin") return {
		ok: false,
		error: "Administrators only."
	};
	await sql`
      update reports set status = ${data.action}
      where id = ${data.id}
    `;
	await sql`
      insert into moderation_actions (report_id, admin_user_id, action, note)
      values (${data.id}, ${context.userId}, ${data.action}, ${data.note.slice(0, 240)})
    `;
	return { ok: true };
});
var verifyCreator_createServerFn_handler = createServerRpc({
	id: "94eaa2c5172519b86a0ed83f33c123cf749edd18127f00f255b05b993003e8b4",
	name: "verifyCreator",
	filename: "src/lib/shelf.functions.ts"
}, (opts) => verifyCreator.__executeServer(opts));
var verifyCreator = createServerFn({ method: "POST" }).validator((input) => {
	if (!VERIFY_STATUS.has(input.status) || typeof input.id !== "number") throw new Error("Invalid verification.");
	return {
		id: input.id,
		status: input.status,
		note: String(input.note ?? "")
	};
}).middleware([authMiddleware]).handler(verifyCreator_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (await roleFor(sql, context.userId) !== "admin") return {
		ok: false,
		error: "Administrators only."
	};
	await sql`
      update creators set verified = ${data.status === "verified"}
      where id = ${data.id}
    `;
	await sql`
      insert into verification_records (creator_id, status, decided_by, note)
      values (${data.id}, ${data.status}, ${context.userId}, ${data.note.slice(0, 240)})
    `;
	return { ok: true };
});
//#endregion
export { addDbComment_createServerFn_handler, addDbReport_createServerFn_handler, adminQueue_createServerFn_handler, listDbComments_createServerFn_handler, moderateReport_createServerFn_handler, myLibrary_createServerFn_handler, setReaction_createServerFn_handler, setSubscription_createServerFn_handler, verifyCreator_createServerFn_handler };
