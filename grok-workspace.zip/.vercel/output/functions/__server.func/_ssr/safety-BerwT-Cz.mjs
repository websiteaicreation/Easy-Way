import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useCurrentUser, i as useToast } from "./router-D2jjv7p6.mjs";
import { n as addDbReport } from "./shelf.functions-C5y8heLN.mjs";
import { d as loadReports, i as addReport } from "./library-D9NbDMrz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/safety-BerwT-Cz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REASONS = [
	"Not what I expected",
	"Copyright",
	"Harassment",
	"Spam",
	"Something else"
];
function SafetyPage() {
	const toast = useToast();
	const user = useCurrentUser();
	const [target, setTarget] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	const [details, setDetails] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [reports, setReports] = (0, import_react.useState)([]);
	const [sent, setSent] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setReports(loadReports());
		try {
			const preset = sessionStorage.getItem("afterdark-report-target");
			if (preset) {
				setTarget(preset);
				sessionStorage.removeItem("afterdark-report-target");
			}
		} catch {}
	}, []);
	async function onSubmit(event) {
		event.preventDefault();
		if (user) {
			const result = await addDbReport({ data: {
				slug: "",
				target,
				reason,
				details
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setError("");
			setDetails("");
			setSent(true);
			toast("Report saved for moderators.");
			return;
		}
		const result = addReport({
			target,
			reason,
			details
		});
		if (result.error) {
			setError(result.error);
			return;
		}
		setError("");
		setDetails("");
		setSent(true);
		setReports(loadReports());
		toast("Report kept on this device. Sign in to send it to moderators.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "page-intro",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "TRUST & SAFETY"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Consent, clarity, and a way to say stop." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Easy Way is an adult-only discovery demo. Signed-in reports are stored for administrators. Reports filed while signed out stay in this browser." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "anchor-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#standards",
							children: "Standards"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#report",
							children: "Report"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#copyright",
							children: "Copyright"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#privacy",
							children: "Privacy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#terms",
							children: "Terms"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "safety-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel policy",
					id: "standards",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Community standards" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Everyone on a real Easy Way shelf would have to be a verified adult. The demo asks once, in the age gate, and remembers that choice for this browser session." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Only adults who want to be here, and only where that is legal." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No one depicted without their consent. No minors, ever — not even fiction presented as a minor." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Harassment, outing, and non-consensual sharing are out." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Creators can withdraw a work. A takedown should beat a trending slot." })
						] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel policy",
					id: "copyright",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Copyright and takedowns" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If a real catalog used your work without permission, you could name the title, where it appears, and how to reach you. This demo has no media files to remove. Use the report form with the reason “Copyright” and it will be stored locally as a sample request." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel policy",
					id: "privacy",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Privacy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "There is no account. Age confirmation lives in session storage. Uploads, saves, likes, comments, and reports live in local storage on this device. Clearing site data deletes them. The demo does not transmit that information." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel policy",
					id: "terms",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Terms" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This is a design prototype, not a video host and not a marketplace. Sample titles are fictional. Thumbnails are generated with color and shape, not photographs. Do not treat the demo as advice, a contract, or a place to upload anyone else’s material." })]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel policy",
				id: "report",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Report content" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tell a moderator what to look at. In this demo the note stays on your device." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "target",
							children: "Video or creator"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "target",
							value: target,
							maxLength: 120,
							placeholder: "Title or creator name",
							onChange: (event) => setTarget(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "reason",
							children: "Reason"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "reason",
							value: reason,
							onChange: (event) => setReason(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Choose one"
							}), REASONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "details",
							children: "Details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "details",
							value: details,
							maxLength: 500,
							placeholder: "What should a moderator know?",
							onChange: (event) => setDetails(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "form-error",
						children: error
					}) : null,
					sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "Saved on this device."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary",
						type: "submit",
						children: "File report"
					}),
					reports.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "comments",
						children: reports.slice(0, 4).map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "comment",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [report.reason, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { children: report.target })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: report.details })]
						}, report.id))
					}) : null
				]
			})]
		})]
	});
}
//#endregion
export { SafetyPage as component };
