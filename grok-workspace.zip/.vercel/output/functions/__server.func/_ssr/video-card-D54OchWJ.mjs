import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as BadgeCheck, m as Play } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/video-card-D54OchWJ.js
var import_jsx_runtime = require_jsx_runtime();
function Thumb({ video }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "thumb",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `thumb-art art-${video.art}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tag",
				children: video.category.toUpperCase()
			}),
			video.local ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "local-flag",
				children: "YOURS"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "play",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
					size: 16,
					fill: "currentColor"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "duration",
				children: video.kind === "photo" ? "PHOTO" : video.kind === "gif" ? "GIF" : video.duration
			})
		]
	});
}
function VideoCard({ video }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/watch/$slug",
		params: { slug: video.slug },
		className: "video-card",
		"aria-label": `Open ${video.title}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { video }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: video.title }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "video-meta",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "creator",
					children: [video.creator, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
						className: "verified",
						size: 12,
						"aria-label": "Verified creator"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "views",
					children: [video.views, " views"]
				})]
			})
		]
	});
}
function RelatedCard({ video }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/watch/$slug",
		params: { slug: video.slug },
		className: "related-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { video }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: video.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			video.creator,
			" · ",
			video.duration
		] })] })]
	});
}
//#endregion
export { VideoCard as n, RelatedCard as t };
