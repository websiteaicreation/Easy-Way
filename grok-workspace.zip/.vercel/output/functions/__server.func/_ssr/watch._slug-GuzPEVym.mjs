import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as BadgeCheck, b as Flag, h as Pause, m as Play, u as Share2, v as Heart } from "../_libs/lucide-react.mjs";
import { a as useCurrentUser, d as SEED_COMMENTS, g as getCatalogVideo, h as formatClock, i as useToast, m as creatorProfile, n as Route$1, y as relatedVideos } from "./router-D2jjv7p6.mjs";
import { t as RelatedCard } from "./video-card-D54OchWJ.mjs";
import { i as listDbComments, s as setReaction, t as addDbComment } from "./shelf.functions-C5y8heLN.mjs";
import { n as addComment, s as loadComments } from "./library-D9NbDMrz.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watch._slug-GuzPEVym.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Player({ video }) {
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setPlaying(false);
		setElapsed(0);
	}, [video.slug]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		let frame = 0;
		let last = performance.now();
		const tick = (now) => {
			const delta = (now - last) / 1e3;
			last = now;
			setElapsed((current) => {
				const next = current + delta * (video.durationSec / 36);
				if (next >= video.durationSec) {
					setPlaying(false);
					return video.durationSec;
				}
				return next;
			});
			frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [playing, video.durationSec]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "player",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: playing ? "player-stage is-playing" : "player-stage",
			"aria-label": playing ? `Pause ${video.title}` : `Play preview of ${video.title}`,
			onClick: () => {
				if (elapsed >= video.durationSec) setElapsed(0);
				setPlaying((value) => !value);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `thumb-art art-${video.art}`,
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tag",
					children: video.category.toUpperCase()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "play",
					children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
						size: 22,
						fill: "currentColor"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
						size: 22,
						fill: "currentColor"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "player-caption",
					children: "Abstract preview — this demo does not stream a video file."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "scrub",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatClock(elapsed) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min: 0,
					max: video.durationSec,
					step: 1,
					value: Math.min(video.durationSec, Math.floor(elapsed)),
					"aria-label": "Preview timeline",
					onChange: (event) => {
						setElapsed(Number(event.target.value));
						setPlaying(false);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: video.duration })
			]
		})]
	});
}
function whenLabel(at) {
	if (!at) return "Featured";
	const delta = Date.now() - at;
	if (delta < 6e4) return "Just now";
	const minutes = Math.floor(delta / 6e4);
	if (minutes < 60) return `${minutes}m ago`;
	const hours = Math.floor(minutes / 60);
	if (hours < 24) return `${hours}h ago`;
	return `${Math.floor(hours / 24)}d ago`;
}
function Comments({ slug }) {
	const toast = useToast();
	const user = useCurrentUser();
	const [items, setItems] = (0, import_react.useState)([]);
	const [remote, setRemote] = (0, import_react.useState)([]);
	const [name, setName] = (0, import_react.useState)("Guest");
	const [text, setText] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function loadLocal() {
		const mine = loadComments(slug);
		const seeds = (SEED_COMMENTS[slug] ?? []).map((comment, index) => ({
			id: `seed-${slug}-${index}`,
			slug,
			user: comment.user,
			text: comment.text,
			at: 0
		}));
		setItems([...mine, ...seeds]);
	}
	(0, import_react.useEffect)(() => {
		loadLocal();
		setText("");
		setError("");
		listDbComments({ data: slug }).then(setRemote).catch(() => setRemote([]));
	}, [slug]);
	async function onSubmit(event) {
		event.preventDefault();
		if (user) {
			const result = await addDbComment({ data: {
				slug,
				body: text
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setError("");
			setText("");
			const next = await listDbComments({ data: slug });
			setRemote(next);
			toast("Comment saved to your account.");
			return;
		}
		const result = addComment(slug, name, text);
		if (result.error) {
			setError(result.error);
			return;
		}
		setError("");
		setText("");
		loadLocal();
		toast("Comment saved on this device. Sign in to keep it on your account.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "comments",
		"aria-labelledby": "comments-heading",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "comments-heading",
				children: "Comments"
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "section-kicker",
				children: "No comments yet. Be the first."
			}) : null,
			remote.map((comment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "comment",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [comment.user, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { children: "Account" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: comment.body })]
			}, `db-${comment.id}`)),
			items.map((comment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "comment",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [comment.user, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { children: whenLabel(comment.at) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: comment.text })]
			}, comment.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "comment-form",
				onSubmit,
				children: [
					user ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						"aria-label": "Display name",
						value: name,
						maxLength: 32,
						onChange: (event) => setName(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						"aria-label": "Comment",
						placeholder: "Add a comment",
						value: text,
						maxLength: 400,
						onChange: (event) => setText(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary",
						type: "submit",
						children: "Post"
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "form-error",
						children: error
					}) : null
				]
			})
		]
	});
}
function WatchPage() {
	const { slug } = Route$1.useParams();
	const { videos, ready, isSaved, isLiked, toggleSaved, toggleLike } = useLibrary();
	const user = useCurrentUser();
	const toast = useToast();
	const video = videos.find((item) => item.slug === slug);
	const known = Boolean(getCatalogVideo(slug));
	if (!video && !known && !ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "empty",
			children: "Loading the shelf…"
		})
	});
	if (!video) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "empty",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "MISSING"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "This video is not on the shelf." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It may have been removed from this device." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "btn primary",
					to: "/",
					children: "Back to trending"
				})
			]
		})
	});
	const current = video;
	const profile = creatorProfile(current.creator);
	const related = relatedVideos(videos, current);
	async function share() {
		try {
			await navigator.clipboard.writeText(window.location.href);
			toast("Link copied.");
		} catch {
			toast("Could not copy the link. Use the browser share menu instead.");
		}
	}
	function report() {
		try {
			sessionStorage.setItem("afterdark-report-target", current.title);
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container watch-layout",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				className: "back-link",
				to: "/",
				hash: "discover",
				children: "← Trending"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, { video: current }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "watch-title",
				children: current.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "video-meta",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "creator",
					children: [current.creator, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
						className: "verified",
						size: 14,
						"aria-label": "Verified creator"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "views",
					children: [
						current.views,
						" views · ",
						current.duration
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "watch-actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn ghost",
						type: "button",
						"aria-pressed": isLiked(current.slug),
						onClick: () => {
							const liked = isLiked(current.slug);
							toggleLike(current.slug);
							if (user) {
								setReaction({ data: {
									slug: current.slug,
									kind: "like",
									on: !liked
								} });
								toast(liked ? "Like removed from your account." : "Liked on your account.");
							} else toast(liked ? "Like removed on this device." : "Liked here. Sign in to keep it on your account.");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
							size: 16,
							fill: isLiked(current.slug) ? "currentColor" : "none"
						}), isLiked(current.slug) ? "Liked" : "Like"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost",
						type: "button",
						"aria-pressed": isSaved(current.slug),
						onClick: () => {
							const saved = isSaved(current.slug);
							toggleSaved(current.slug);
							if (user) {
								setReaction({ data: {
									slug: current.slug,
									kind: "favorite",
									on: !saved
								} });
								toast(saved ? "Removed from your favorites." : "Saved to your favorites.");
							} else toast(saved ? "Removed on this device." : "Saved here. Sign in to keep it on your account.");
						},
						children: isSaved(current.slug) ? "Saved" : "Save"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn ghost",
						type: "button",
						onClick: () => void share(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { size: 16 }), "Share"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						className: "btn ghost",
						to: "/safety",
						hash: "report",
						onClick: report,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { size: 16 }), "Report"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "synopsis",
				children: current.synopsis
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "creator-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `avatar thumb-art art-${current.art}`,
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: current.creator }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: profile ? `${profile.place} — ${profile.bio}` : "Independent creator on this demo shelf." }),
					profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						className: "back-link",
						to: "/creator/$slug",
						params: { slug: profile.slug },
						children: "View profile →"
					}) : null
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comments, { slug: current.slug })
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "related",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Up next" }), related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelatedCard, { video: item }, item.slug))]
		})]
	});
}
//#endregion
export { WatchPage as component };
