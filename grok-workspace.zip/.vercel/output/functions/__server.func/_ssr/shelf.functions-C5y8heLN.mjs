import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-CAK7_l_2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shelf.functions-C5y8heLN.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var REACTION = /* @__PURE__ */ new Set(["like", "favorite"]);
var REPORT_STATUS = /* @__PURE__ */ new Set([
	"reviewed",
	"dismissed",
	"removed"
]);
var VERIFY_STATUS = /* @__PURE__ */ new Set(["verified", "rejected"]);
var myLibrary = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("28406c582cdb9a8f5f0282215ac8678dc7f82c1aecef4b7006daae2efb6a1ed3"));
var setReaction = createServerFn({ method: "POST" }).validator((input) => {
	if (!REACTION.has(input.kind) || typeof input.slug !== "string" || typeof input.on !== "boolean") throw new Error("Invalid reaction.");
	return {
		slug: input.slug,
		kind: input.kind,
		on: input.on
	};
}).middleware([authMiddleware]).handler(createSsrRpc("c3ebcc6df956902608e0c0afbeed8a493b0557c1bb019d4037d951cd3626c447"));
var setSubscription = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("87c0231719693d92f2ea3e533663cb21ffda35029ebadf1618305d09eb5a7a5d"));
var listDbComments = createServerFn({ method: "GET" }).validator((slug) => slug).handler(createSsrRpc("2eea7e92cbbb588779dae2819e4cfb2a5d0531e7eb0eca75620f0e482baa1372"));
var addDbComment = createServerFn({ method: "POST" }).validator((input) => ({
	slug: input.slug,
	body: input.body.trim()
})).middleware([authMiddleware]).handler(createSsrRpc("77d1bfae8e733aecc6468b60111b696523f4ffd3b8c0619c4ed35e216b3dc291"));
var addDbReport = createServerFn({ method: "POST" }).validator((input) => ({
	slug: input.slug.trim(),
	target: input.target.trim().slice(0, 120),
	reason: input.reason.trim(),
	details: input.details.trim()
})).middleware([authMiddleware]).handler(createSsrRpc("eb950e5f38c0356097c6e1c099ee8f10d7696a6ecb799415432d838c7da9c8e5"));
var adminQueue = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d372880cbd083f8ad60e09f2b4b87d2867b5afd3da81658242ee79c7d12f6aba"));
var moderateReport = createServerFn({ method: "POST" }).validator((input) => {
	if (!REPORT_STATUS.has(input.action) || typeof input.id !== "number") throw new Error("Invalid moderation action.");
	return {
		id: input.id,
		action: input.action,
		note: String(input.note ?? "")
	};
}).middleware([authMiddleware]).handler(createSsrRpc("0f283c2797580d1afd8b764ed86695a8b74124d6abebcac5856b3d92c8b59e42"));
var verifyCreator = createServerFn({ method: "POST" }).validator((input) => {
	if (!VERIFY_STATUS.has(input.status) || typeof input.id !== "number") throw new Error("Invalid verification.");
	return {
		id: input.id,
		status: input.status,
		note: String(input.note ?? "")
	};
}).middleware([authMiddleware]).handler(createSsrRpc("94eaa2c5172519b86a0ed83f33c123cf749edd18127f00f255b05b993003e8b4"));
//#endregion
export { moderateReport as a, setSubscription as c, listDbComments as i, verifyCreator as l, addDbReport as n, myLibrary as o, adminQueue as r, setReaction as s, addDbComment as t };
