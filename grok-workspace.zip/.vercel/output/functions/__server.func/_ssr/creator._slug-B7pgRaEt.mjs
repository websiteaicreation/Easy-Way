import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as BadgeCheck } from "../_libs/lucide-react.mjs";
import { _ as getCreator, a as useCurrentUser, i as useToast, r as Route$2 } from "./router-D2jjv7p6.mjs";
import { n as VideoCard } from "./video-card-D54OchWJ.mjs";
import { c as setSubscription } from "./shelf.functions-C5y8heLN.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/creator._slug-B7pgRaEt.js
var import_jsx_runtime = require_jsx_runtime();
function CreatorPage() {
	const { slug } = Route$2.useParams();
	const creator = getCreator(slug);
	const toast = useToast();
	const { videos, follows, toggleFollow } = useLibrary();
	const user = useCurrentUser();
	if (!creator) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "empty",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "MISSING"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "That creator is not on the shelf." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "btn primary",
					to: "/",
					hash: "creators",
					children: "Browse creators"
				})
			]
		})
	});
	const theirs = videos.filter((video) => video.creator === creator.name);
	const following = follows.includes(creator.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "creator-hero",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `avatar large thumb-art art-${creator.art}`,
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shape" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: creator.place.toUpperCase()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [creator.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
					className: "verified",
					size: 18,
					"aria-label": "Verified creator"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: creator.bio }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "action-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary",
						type: "button",
						"aria-pressed": following,
						onClick: () => {
							toggleFollow(creator.slug);
							if (user) {
								setSubscription({ data: {
									slug: creator.slug,
									on: !following
								} });
								toast(following ? `Unsubscribed from ${creator.name}.` : `Subscribed to ${creator.name}.`);
							} else toast(following ? `Unfollowed ${creator.name} on this device.` : `Following ${creator.name} here. Sign in to subscribe.`);
						},
						children: following ? "Following" : "Follow"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						className: "btn ghost",
						to: "/",
						hash: "discover",
						children: theirs.length === 1 ? "1 video" : `${theirs.length} videos`
					})]
				})
			] })]
		}), theirs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "video-grid",
			children: theirs.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, { video }, video.slug))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "empty",
			children: "No videos from this creator yet."
		})]
	});
}
//#endregion
export { CreatorPage as component };
