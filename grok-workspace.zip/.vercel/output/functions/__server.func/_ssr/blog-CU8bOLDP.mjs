import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blog-CU8bOLDP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var POSTS = [
	{
		id: "reports",
		kicker: "TRUST",
		title: "What happens after you file a report",
		lede: "A report on this demo stays in the browser. Here is the path a real desk would follow.",
		body: "You name the title, pick a reason, and add enough detail that someone else could find the same card. On a live site that note would go to a moderator queue, not a public thread. Copyright claims use the same form and should include where the original lives. Nothing here is sent to a server."
	},
	{
		id: "sets",
		kicker: "STUDIO",
		title: "Before you publish from Creator Studio",
		lede: "The studio writes a card onto this device and drops it into Trending.",
		body: "Use a title someone can search, a duration in minutes and seconds, and a synopsis that says what the piece is about. Categories match the shelf chips. Removing a card only removes your upload — the sample shelf stays. If you are testing a real launch later, replace the sample policies before anyone else can see the studio."
	},
	{
		id: "region",
		kicker: "SHELF",
		title: "Why Hottest in Morocco is its own lane",
		lede: "Regional shelves are a filter, not a ranking of people.",
		body: "The Morocco lane only shows cards tagged to that region. It sits next to Featured, Clips, and Shorties so a visitor in Marrakech can start close to home and still jump to the full catalog. The star in the menu marks the lane. It does not change how reports or saves work."
	}
];
function BlogPage() {
	const [open, setOpen] = (0, import_react.useState)(POSTS[0]?.id ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "page-intro",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "STORIES"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "From the desk" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Notes on the shelf, the studio, and how reports are meant to work." })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stack",
			children: POSTS.map((post) => {
				const shown = open === post.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel thread",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "thread-toggle",
						onClick: () => setOpen(shown ? "" : post.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
								className: "eyebrow",
								children: post.kicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: post.title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: post.lede })
						] })
					}), shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "thread-body",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: post.body }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "back-link",
							to: "/safety",
							children: "Trust & Safety →"
						})]
					}) : null]
				}, post.id);
			})
		})]
	});
}
//#endregion
export { BlogPage as component };
