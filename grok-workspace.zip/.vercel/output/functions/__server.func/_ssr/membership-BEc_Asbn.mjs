import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Check } from "../_libs/lucide-react.mjs";
import { i as useToast } from "./router-D2jjv7p6.mjs";
import { g as setMemberName } from "./library-D9NbDMrz.mjs";
import { t as useLibrary } from "./use-library-BIZzxVQ4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/membership-BEc_Asbn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PERKS = [
	"The full shelf stays open — featured, clips, shorties, GIFs, and photos.",
	"A member name on this device, shown on your library.",
	"Saved videos and likes stay with you in this browser.",
	"Creator Studio publishing, without a paywall."
];
function MembershipPage() {
	const toast = useToast();
	const { memberName } = useLibrary();
	const [name, setName] = (0, import_react.useState)(memberName);
	const [error, setError] = (0, import_react.useState)("");
	function onJoin(event) {
		event.preventDefault();
		const next = name.trim();
		if (next.length < 2) {
			setError("Add the name you want on this device.");
			return;
		}
		setError("");
		setMemberName(next);
		toast("Membership saved on this device. Nothing was charged.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "page-intro",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "MEMBERSHIP"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Full Easy Way" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This is a demo membership. Joining stores a name in this browser. There is no payment and no account server." })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: memberName ? `You’re in as ${memberName}` : "What you get" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "perk-list",
					children: PERKS.map((perk) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						size: 16,
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })] }, perk))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: onJoin,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: ["Name on this device", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								maxLength: 32,
								placeholder: "How should the shelf greet you?",
								onChange: (event) => setName(event.target.value)
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "form-error",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "action-row",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn primary",
									type: "submit",
									children: memberName ? "Update name" : "Join on this device"
								}),
								memberName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn ghost",
									type: "button",
									onClick: () => {
										setMemberName("");
										setName("");
										toast("Membership cleared on this device.");
									},
									children: "Leave"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									className: "btn ghost",
									to: "/",
									children: "Back to the shelf"
								})
							]
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { MembershipPage as component };
