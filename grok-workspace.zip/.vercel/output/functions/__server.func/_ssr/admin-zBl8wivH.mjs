import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useCurrentUserState } from "./router-D2jjv7p6.mjs";
import { t as RedirectToSignIn } from "./gates-C0oqvQwR.mjs";
import { a as moderateReport, l as verifyCreator, r as adminQueue } from "./shelf.functions-C5y8heLN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-zBl8wivH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminPage() {
	const { user, isPending } = useCurrentUserState();
	const [queue, setQueue] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	function refresh() {
		adminQueue().then((result) => {
			if (!result.ok) {
				setError(result.error);
				setQueue(null);
				return;
			}
			setError("");
			setQueue(result);
		}).catch(() => setError("Could not load the queue."));
	}
	const userId = user?.id;
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		refresh();
	}, [userId]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "container",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "empty",
			children: "Checking your session…"
		})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "container page-stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-intro",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "ADMIN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Moderation" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Reports and verification records. Only an administrator account can change them." })
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "empty",
				children: error
			}) : null,
			queue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Reports" }),
					queue.reports.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "No reports yet."
					}) : null,
					queue.reports.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "comment",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
								report.target,
								" · ",
								report.status
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								report.reason,
								". ",
								report.details
							] }),
							report.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "action-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn ghost",
										type: "button",
										onClick: () => {
											moderateReport({ data: {
												id: report.id,
												action: "reviewed",
												note: ""
											} }).then(refresh);
										},
										children: "Mark reviewed"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn ghost",
										type: "button",
										onClick: () => {
											moderateReport({ data: {
												id: report.id,
												action: "dismissed",
												note: ""
											} }).then(refresh);
										},
										children: "Dismiss"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn ghost",
										type: "button",
										onClick: () => {
											moderateReport({ data: {
												id: report.id,
												action: "removed",
												note: ""
											} }).then(refresh);
										},
										children: "Remove"
									})
								]
							}) : null
						]
					}, report.id))
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Verification" }), queue.creators.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "upload-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: creator.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: creator.verified ? "Verified" : "Not verified"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost",
						type: "button",
						onClick: () => {
							verifyCreator({ data: {
								id: creator.id,
								status: creator.verified ? "rejected" : "verified",
								note: ""
							} }).then(refresh);
						},
						children: creator.verified ? "Remove" : "Verify"
					})]
				}, creator.id))]
			})] }) : null
		]
	});
}
//#endregion
export { AdminPage as component };
