//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B0Rngqcc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/account",
			"/admin",
			"/blog",
			"/community",
			"/insights",
			"/login",
			"/membership",
			"/safety",
			"/studio",
			"/creator/$slug",
			"/watch/$slug",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-38Bd2KiI.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CBlnwed1.js",
			"/assets/link-FStLKvPX.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/lazyRouteComponent-CTBzah4h.js",
			"/assets/use-current-user-DZJD53VE.js",
			"/assets/useRouter-CnG7R4es.js",
			"/assets/shell-CqGxk0wT.js",
			"/assets/play-CF1u96s5.js",
			"/assets/catalog-f7z9RYjX.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-38Bd2KiI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CdWzWTQ9.js",
			"/assets/browse-cFywtdPV.js",
			"/assets/video-card-BUBpn2TH.js",
			"/assets/use-library-Cm8JByMW.js"
		]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-LYE5ueSN.js"]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-ByUGTp_m.js",
			"/assets/shelf.functions-DF5GZB_W.js",
			"/assets/video-card-BUBpn2TH.js",
			"/assets/gates-CHUwaqID.js",
			"/assets/use-library-Cm8JByMW.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DhSFy4XE.js",
			"/assets/shelf.functions-DF5GZB_W.js",
			"/assets/gates-CHUwaqID.js"
		]
	},
	"/blog": {
		filePath: "/workspace/src/routes/blog.tsx",
		children: void 0,
		preloads: ["/assets/blog-tNmGMqwd.js"]
	},
	"/community": {
		filePath: "/workspace/src/routes/community.tsx",
		children: void 0,
		preloads: ["/assets/community-Csb039aq.js", "/assets/library-Dxde-l1P.js"]
	},
	"/insights": {
		filePath: "/workspace/src/routes/insights.tsx",
		children: void 0,
		preloads: ["/assets/insights-B13B2WGW.js", "/assets/use-library-Cm8JByMW.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-jYWRxcHo.js",
			"/assets/client-cLw6edTc.js",
			"/assets/gates-CHUwaqID.js"
		]
	},
	"/membership": {
		filePath: "/workspace/src/routes/membership.tsx",
		children: void 0,
		preloads: [
			"/assets/membership-DpZ1Ej6W.js",
			"/assets/library-Dxde-l1P.js",
			"/assets/use-library-Cm8JByMW.js"
		]
	},
	"/safety": {
		filePath: "/workspace/src/routes/safety.tsx",
		children: void 0,
		preloads: [
			"/assets/safety-w2YO_daD.js",
			"/assets/shelf.functions-DF5GZB_W.js",
			"/assets/library-Dxde-l1P.js"
		]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-gODzC-5B.js",
			"/assets/library-Dxde-l1P.js",
			"/assets/use-library-Cm8JByMW.js"
		]
	},
	"/creator/$slug": {
		filePath: "/workspace/src/routes/creator.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/creator._slug-ymlSw-sl.js",
			"/assets/shelf.functions-DF5GZB_W.js",
			"/assets/video-card-BUBpn2TH.js",
			"/assets/use-library-Cm8JByMW.js"
		]
	},
	"/watch/$slug": {
		filePath: "/workspace/src/routes/watch.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/watch._slug-BU1ETz3q.js",
			"/assets/shelf.functions-DF5GZB_W.js",
			"/assets/video-card-BUBpn2TH.js",
			"/assets/library-Dxde-l1P.js",
			"/assets/use-library-Cm8JByMW.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
