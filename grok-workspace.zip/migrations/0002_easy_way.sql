-- Easy Way shelf. Per-user rows use user_id text (Better Auth ids).
-- The app connection is the table owner, so it enforces these rules in server
-- functions. Row Level Security is still enabled for any non-owner role.
-- Table owners bypass RLS unless forced; we do not force it, or the app
-- connection (the equivalent of a service role) could not run scoped queries.
-- A restricted role would be limited by the policies below.

create table if not exists profiles (
  user_id text primary key references "user" ("id") on delete cascade,
  display_name text not null default '',
  role text not null default 'member' check (role in ('member', 'creator', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists categories (
  id serial primary key,
  name text not null unique
);

create table if not exists creators (
  id serial primary key,
  slug text not null unique,
  name text not null unique,
  place text not null default '',
  bio text not null default '',
  art text not null default 'amber',
  owner_user_id text references "user" ("id") on delete set null,
  verified boolean not null default false
);

create table if not exists videos (
  id serial primary key,
  slug text not null unique,
  title text not null,
  creator_id integer not null references creators (id),
  category_id integer not null references categories (id),
  synopsis text not null default '',
  duration_sec integer not null,
  views_num integer not null default 0,
  art text not null default 'amber',
  kind text not null default 'video',
  featured boolean not null default false,
  region text,
  created_at timestamptz not null default now()
);

create table if not exists likes (
  user_id text not null references "user" ("id") on delete cascade,
  video_id integer not null references videos (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, video_id)
);

create table if not exists favorites (
  user_id text not null references "user" ("id") on delete cascade,
  video_id integer not null references videos (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, video_id)
);

create table if not exists comments (
  id serial primary key,
  user_id text not null references "user" ("id") on delete cascade,
  video_id integer not null references videos (id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists subscriptions (
  user_id text not null references "user" ("id") on delete cascade,
  creator_id integer not null references creators (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, creator_id)
);

create table if not exists reports (
  id serial primary key,
  user_id text not null references "user" ("id") on delete cascade,
  video_id integer references videos (id) on delete set null,
  target text not null,
  reason text not null,
  details text not null,
  status text not null default 'pending' check (status in ('pending', 'reviewed', 'dismissed', 'removed')),
  created_at timestamptz not null default now()
);

create table if not exists moderation_actions (
  id serial primary key,
  report_id integer not null references reports (id) on delete cascade,
  admin_user_id text not null references "user" ("id"),
  action text not null,
  note text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists verification_records (
  id serial primary key,
  creator_id integer not null references creators (id) on delete cascade,
  status text not null check (status in ('pending', 'verified', 'rejected')),
  decided_by text references "user" ("id"),
  note text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists comments_video_idx on comments (video_id);
create index if not exists reports_status_idx on reports (status);

alter table profiles enable row level security;
alter table categories enable row level security;
alter table creators enable row level security;
alter table videos enable row level security;
alter table likes enable row level security;
alter table favorites enable row level security;
alter table comments enable row level security;
alter table subscriptions enable row level security;
alter table reports enable row level security;
alter table moderation_actions enable row level security;
alter table verification_records enable row level security;

create policy categories_read on categories for select using (true);
create policy creators_read on creators for select using (true);
create policy videos_read on videos for select using (true);
create policy comments_read on comments for select using (true);

create policy profiles_self on profiles for all
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

create policy likes_self on likes for all
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

create policy favorites_self on favorites for all
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

create policy comments_self_write on comments for insert
  with check (user_id = current_setting('app.user_id', true));

create policy subscriptions_self on subscriptions for all
  using (user_id = current_setting('app.user_id', true))
  with check (user_id = current_setting('app.user_id', true));

create policy reports_self_read on reports for select
  using (
    user_id = current_setting('app.user_id', true)
    or current_setting('app.role', true) = 'admin'
  );

create policy reports_self_insert on reports for insert
  with check (user_id = current_setting('app.user_id', true));

create policy moderation_admin on moderation_actions for all
  using (current_setting('app.role', true) = 'admin')
  with check (current_setting('app.role', true) = 'admin');

create policy verification_admin on verification_records for all
  using (current_setting('app.role', true) = 'admin')
  with check (current_setting('app.role', true) = 'admin');

insert into categories (name) values
  ('Lesbian'),
  ('18-25'),
  ('MILF'),
  ('Popular With Women'),
  ('Anal'),
  ('Threesome'),
  ('Mature'),
  ('Hentai'),
  ('Ebony'),
  ('Japanese')
on conflict (name) do nothing;

insert into creators (slug, name, place, bio, art) values
  ('mila-studio', 'Mila Studio', 'Marrakech', 'Diary films about city light, riads, and the rooms people actually live in.', 'amber'),
  ('northlight', 'Northlight', 'Montreal', 'Illustrated loops and paced clips.', 'rose'),
  ('studio-june', 'Studio June', 'Tokyo', 'Short films about affection, distance, and late conversations.', 'violet'),
  ('lena-moves', 'Lena Moves', 'Austin', 'Shorties and slow mornings.', 'green'),
  ('easy-way-originals', 'Easy Way Originals', 'Remote', 'Interviews and photo sets.', 'blue'),
  ('the-sunday-set', 'The Sunday Set', 'London', 'Small-cast nights.', 'gold')
on conflict (slug) do nothing;

insert into videos (slug, title, creator_id, category_id, synopsis, duration_sec, views_num, art, kind, featured, region)
select v.slug, v.title, c.id, g.id, v.synopsis, v.duration_sec, v.views_num, v.art, v.kind, v.featured, v.region
from (values
  ('a-weekend-in-the-city-creator-diary', 'A Weekend in the City — Together', 'Mila Studio', 'Lesbian', 'Two women share a Saturday market, a late train, and one apartment.', 768, 248000, 'amber', 'video', true, 'morocco'),
  ('behind-the-scenes-a-creative-day', 'Slow, and On Her Terms', 'Northlight', 'Anal', 'A paced clip about checking in and stopping when someone asks.', 496, 192000, 'rose', 'clip', false, null),
  ('a-little-romance-short-film', 'After Class, Before Midnight', 'Studio June', '18-25', 'Two adults share a booth and one honest conversation.', 1083, 184000, 'violet', 'video', true, null),
  ('morning-movement-and-wellness', 'The Morning She Stayed', 'Lena Moves', 'Popular With Women', 'A slow morning between partners.', 582, 96000, 'green', 'video', false, null),
  ('the-after-hours-interview', 'Unhurried — After Hours', 'Easy Way Originals', 'Mature', 'A long conversation about boundaries and schedules.', 1331, 87000, 'blue', 'video', true, null),
  ('two-truths-and-a-story', 'Three at the Table', 'The Sunday Set', 'Threesome', 'Three adults decide, out loud, what they want from the night.', 395, 76000, 'gold', 'video', false, null),
  ('marrakech-heat', 'Marrakech Heat', 'Mila Studio', 'Lesbian', 'A riad, two women, and the fan that never quite keeps up.', 665, 121000, 'rose', 'video', true, 'morocco')
) as v(slug, title, creator, category, synopsis, duration_sec, views_num, art, kind, featured, region)
join creators c on c.name = v.creator
join categories g on g.name = v.category
on conflict (slug) do nothing;
