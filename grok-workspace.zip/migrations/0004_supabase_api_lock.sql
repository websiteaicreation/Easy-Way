-- Supabase Data API lockdown.
-- The app connects as the database owner, so these policies do not block it.
-- anon and authenticated are the roles behind the publishable key. They may
-- read the public catalog only. Accounts, sessions, and engagement stay closed.

alter table "user" enable row level security;
alter table "session" enable row level security;
alter table "account" enable row level security;
alter table "verification" enable row level security;

revoke all on table "user" from anon, authenticated;
revoke all on table "session" from anon, authenticated;
revoke all on table "account" from anon, authenticated;
revoke all on table "verification" from anon, authenticated;

revoke all on table profiles from anon, authenticated;
revoke all on table likes from anon, authenticated;
revoke all on table favorites from anon, authenticated;
revoke all on table comments from anon, authenticated;
revoke all on table subscriptions from anon, authenticated;
revoke all on table reports from anon, authenticated;
revoke all on table moderation_actions from anon, authenticated;
revoke all on table verification_records from anon, authenticated;

revoke all on table categories from anon, authenticated;
revoke all on table creators from anon, authenticated;
revoke all on table videos from anon, authenticated;
grant select on table categories to anon, authenticated;
grant select on table creators to anon, authenticated;
grant select on table videos to anon, authenticated;

revoke all on all sequences in schema public from anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
