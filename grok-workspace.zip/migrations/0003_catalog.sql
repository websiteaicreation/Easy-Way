-- Remaining shelf videos, so likes, comments, and reports can attach to every title.
-- Also records the admin-only update path for reports. The app connection is the
-- table owner and bypasses row level security; server functions still check the
-- signed-in user, and only profiles.role = 'admin' may write moderation rows.

insert into videos (slug, title, creator_id, category_id, synopsis, duration_sec, views_num, art, kind, featured, region)
select v.slug, v.title, c.id, g.id, v.synopsis, v.duration_sec, v.views_num, v.art, v.kind, v.featured, v.region
from (values
  ('a-quiet-evening-creator-diary', 'The Evening She Kept', 'Mila Studio', 'MILF', 'Cooking for one, notes for tomorrow’s shoot, and a window left open.', 860, 65000, 'rose', 'video', true, null::text),
  ('making-the-set-studio-notes', 'Ink After Dark', 'Northlight', 'Hentai', 'An illustrated short. Abstract frames and ink, no live actors.', 252, 58000, 'violet', 'clip', false, null),
  ('a-sunday-reset-home-and-habits', 'Golden Hour in the Riad', 'Mila Studio', 'Ebony', 'Studio light in a Marrakech riad.', 472, 51000, 'amber', 'video', true, 'morocco'),
  ('the-art-of-the-short-film', 'Tokyo, After the Train', 'Studio June', 'Japanese', 'Blocking, silence, and why the film ends one line earlier than expected.', 984, 43000, 'rose', 'video', false, null),
  ('stretch-breathe-recharge', 'Riad Glow', 'Lena Moves', '18-25', 'A shorty from a riad courtyard.', 46, 39000, 'green', 'short', false, 'morocco'),
  ('creator-q-and-a-getting-started', 'Still, Set One', 'Easy Way Originals', 'Ebony', 'A photo set. One still, held.', 12, 31000, 'blue', 'photo', false, null),
  ('atlas-light-clip', 'Atlas Light', 'Mila Studio', 'MILF', 'A three-minute clip shot against the High Atlas at dusk.', 200, 44000, 'gold', 'clip', false, 'morocco'),
  ('three-count-shorty', 'Three Count', 'The Sunday Set', 'Threesome', 'A shorty: three people, one countdown, and a laugh.', 38, 28000, 'gold', 'short', false, null),
  ('amber-loop', 'Amber Loop', 'Lena Moves', 'Popular With Women', 'A looping GIF. Warm light, a turn of the shoulder.', 6, 22000, 'amber', 'gif', false, 'morocco'),
  ('ink-loop', 'Ink Loop', 'Northlight', 'Hentai', 'An ink loop. Illustrated only.', 8, 19000, 'violet', 'gif', false, null),
  ('window-light-still', 'Window Light Still', 'Studio June', 'Japanese', 'A single window-light still from the Tokyo set.', 10, 17000, 'rose', 'photo', false, null)
) as v(slug, title, creator, category, synopsis, duration_sec, views_num, art, kind, featured, region)
join creators c on c.name = v.creator
join categories g on g.name = v.category
on conflict (slug) do nothing;

create index if not exists likes_user_idx on likes (user_id);
create index if not exists favorites_user_idx on favorites (user_id);
create index if not exists subscriptions_user_idx on subscriptions (user_id);
create index if not exists videos_creator_idx on videos (creator_id);
create index if not exists videos_category_idx on videos (category_id);

drop policy if exists reports_admin_update on reports;
create policy reports_admin_update on reports for update
  using (current_setting('app.role', true) = 'admin')
  with check (current_setting('app.role', true) = 'admin');
