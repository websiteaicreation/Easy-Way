import {
  CATALOG,
  CATEGORIES,
  artForCategory,
  parseDuration,
  slugify,
  type Category,
  type Video,
} from "@/lib/catalog";

const UPLOADS_KEY = "afterdark-uploads";
const SAVED_KEY = "afterdark-saved";
const LIKES_KEY = "afterdark-likes";
const COMMENTS_KEY = "afterdark-comments";
const REPORTS_KEY = "afterdark-reports";
const MEMBER_KEY = "afterdark-member";
const FOLLOWS_KEY = "afterdark-follows";
const THREADS_KEY = "afterdark-threads";
export const LIBRARY_EVENT = "afterdark-sync";

export type StoredComment = {
  id: string;
  slug: string;
  user: string;
  text: string;
  at: number;
};

export type StoredReport = {
  id: string;
  target: string;
  reason: string;
  details: string;
  at: number;
};

export type ThreadReply = {
  id: string;
  author: string;
  body: string;
  at: number;
};

export type Thread = {
  id: string;
  title: string;
  body: string;
  author: string;
  at: number;
  replies: ThreadReply[];
};

export type UploadInput = {
  title: string;
  creator: string;
  category: Category;
  duration: string;
  synopsis: string;
};

function canUseStorage(): boolean {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

function readJson<T>(key: string, fallback: T): T {
  if (!canUseStorage()) return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  if (!canUseStorage()) return;
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new Event(LIBRARY_EVENT));
}

function isCategory(value: unknown): value is Category {
  return typeof value === "string" && (CATEGORIES as readonly string[]).includes(value);
}

function isVideo(value: unknown): value is Video {
  if (!value || typeof value !== "object") return false;
  const video = value as Partial<Video>;
  return (
    typeof video.slug === "string" &&
    typeof video.title === "string" &&
    typeof video.creator === "string" &&
    typeof video.category === "string" &&
    typeof video.duration === "string" &&
    typeof video.durationSec === "number" &&
    typeof video.synopsis === "string"
  );
}

export function loadUploads(): Video[] {
  return readJson<unknown[]>(UPLOADS_KEY, []).filter(isVideo).map((video) => ({
    ...video,
    views: video.views || "New",
    viewsNum: video.viewsNum || 0,
    time: video.time || 0,
    category: isCategory(video.category) ? video.category : "Mature",
    art: video.art || artForCategory(isCategory(video.category) ? video.category : "Mature"),
    local: true,
  }));
}

export function loadSaved(): string[] {
  return readJson<unknown[]>(SAVED_KEY, []).filter((item): item is string => typeof item === "string");
}

export function loadLikes(): string[] {
  return readJson<unknown[]>(LIKES_KEY, []).filter((item): item is string => typeof item === "string");
}

export function loadComments(slug: string): StoredComment[] {
  return readJson<StoredComment[]>(COMMENTS_KEY, [])
    .filter(
      (comment) =>
        comment &&
        comment.slug === slug &&
        typeof comment.text === "string" &&
        typeof comment.user === "string",
    )
    .sort((a, b) => b.at - a.at);
}

export function loadReports(): StoredReport[] {
  return readJson<StoredReport[]>(REPORTS_KEY, [])
    .filter((report) => report && typeof report.reason === "string")
    .sort((a, b) => b.at - a.at);
}

function uniqueSlug(title: string): string {
  const taken = new Set<string>([
    ...CATALOG.map((video) => video.slug),
    ...loadUploads().map((video) => video.slug),
  ]);
  const base = slugify(title);
  if (!taken.has(base)) return base;
  let n = 2;
  while (taken.has(`${base}-${n}`)) n += 1;
  return `${base}-${n}`;
}

export function addUpload(input: UploadInput): { video?: Video; error?: string } {
  const title = input.title.trim();
  const creator = input.creator.trim();
  const synopsis = input.synopsis.trim();
  const durationSec = parseDuration(input.duration);
  if (title.length < 3) return { error: "Give the video a title of at least 3 characters." };
  if (title.length > 80) return { error: "Keep the title under 80 characters." };
  if (creator.length < 2) return { error: "Add the creator name." };
  if (creator.length > 40) return { error: "Creator name is too long." };
  if (durationSec == null) return { error: "Duration should look like 08:16, under 3 hours." };
  if (synopsis.length < 12) return { error: "Add a short synopsis — at least a sentence." };
  if (synopsis.length > 280) return { error: "Synopsis must stay under 280 characters." };
  if (loadUploads().length >= 24) return { error: "This demo shelf holds 24 uploads. Remove one first." };

  const minutes = Math.floor(durationSec / 60);
  const seconds = durationSec % 60;
  const video: Video = {
    slug: uniqueSlug(title),
    title,
    creator,
    category: input.category,
    views: "New",
    viewsNum: 0,
    duration: `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`,
    durationSec,
    time: Date.now(),
    art: artForCategory(input.category),
    synopsis,
    local: true,
  };
  writeJson(UPLOADS_KEY, [video, ...loadUploads()]);
  return { video };
}

export function removeUpload(slug: string) {
  writeJson(
    UPLOADS_KEY,
    loadUploads().filter((video) => video.slug !== slug),
  );
  writeJson(
    SAVED_KEY,
    loadSaved().filter((item) => item !== slug),
  );
  writeJson(
    LIKES_KEY,
    loadLikes().filter((item) => item !== slug),
  );
}

function toggleId(key: string, slug: string): boolean {
  const current = readJson<string[]>(key, []).filter((item) => typeof item === "string");
  const has = current.includes(slug);
  writeJson(
    key,
    has ? current.filter((item) => item !== slug) : [slug, ...current],
  );
  return !has;
}

export function toggleSaved(slug: string): boolean {
  return toggleId(SAVED_KEY, slug);
}

export function toggleLike(slug: string): boolean {
  return toggleId(LIKES_KEY, slug);
}

export function addComment(slug: string, user: string, text: string): { error?: string } {
  const name = user.trim() || "Guest";
  const body = text.trim();
  if (name.length > 32) return { error: "Name must be under 32 characters." };
  if (body.length < 2) return { error: "Write a comment first." };
  if (body.length > 400) return { error: "Comments stay under 400 characters." };
  const next: StoredComment = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    slug,
    user: name,
    text: body,
    at: Date.now(),
  };
  const all = readJson<StoredComment[]>(COMMENTS_KEY, []);
  writeJson(COMMENTS_KEY, [next, ...all].slice(0, 200));
  return {};
}

export function addReport(input: {
  target: string;
  reason: string;
  details: string;
}): { error?: string } {
  const target = input.target.trim();
  const details = input.details.trim();
  if (!input.reason) return { error: "Choose a reason." };
  if (target.length < 2) return { error: "Say what you are reporting." };
  if (details.length < 8) return { error: "Add a few details so a moderator could act." };
  if (details.length > 500) return { error: "Keep the note under 500 characters." };
  const report: StoredReport = {
    id: `${Date.now()}`,
    target: target.slice(0, 120),
    reason: input.reason,
    details,
    at: Date.now(),
  };
  writeJson(REPORTS_KEY, [report, ...loadReports()].slice(0, 40));
  return {};
}

export function loadMemberName(): string {
  if (!canUseStorage()) return "";
  return (localStorage.getItem(MEMBER_KEY) ?? "").slice(0, 32);
}

export function setMemberName(name: string) {
  if (!canUseStorage()) return;
  const next = name.trim().slice(0, 32);
  if (!next) localStorage.removeItem(MEMBER_KEY);
  else localStorage.setItem(MEMBER_KEY, next);
  window.dispatchEvent(new Event(LIBRARY_EVENT));
}

export function loadFollows(): string[] {
  return readJson<unknown[]>(FOLLOWS_KEY, []).filter((item): item is string => typeof item === "string");
}

export function toggleFollow(slug: string) {
  const current = loadFollows();
  const next = current.includes(slug) ? current.filter((item) => item !== slug) : [slug, ...current];
  writeJson(FOLLOWS_KEY, next);
}

const SEED_THREADS: Thread[] = [
  {
    id: "seed-schedules",
    title: "How do you film a short without rushing the last take?",
    body: "Studio June leaves the last ten minutes unscripted. Curious what other sets do when the light is already gone.",
    author: "Hana",
    at: 0,
    replies: [
      {
        id: "seed-schedules-1",
        author: "Lena",
        body: "We stop. A tired take reads as tired, and the edit cannot hide that.",
        at: 0,
      },
    ],
  },
  {
    id: "seed-morocco",
    title: "Shooting in Marrakech without turning the city into a backdrop",
    body: "Mila’s riad films feel lived-in. What do you ask a location before you bring a camera in?",
    author: "Nora",
    at: 0,
    replies: [],
  },
];

function isThread(value: unknown): value is Thread {
  if (!value || typeof value !== "object") return false;
  const thread = value as Partial<Thread>;
  return (
    typeof thread.id === "string" &&
    typeof thread.title === "string" &&
    typeof thread.body === "string" &&
    typeof thread.author === "string" &&
    Array.isArray(thread.replies)
  );
}

export function loadThreads(): Thread[] {
  if (!canUseStorage() || localStorage.getItem(THREADS_KEY) == null) return SEED_THREADS;
  return readJson<unknown[]>(THREADS_KEY, []).filter(isThread);
}

export function addThread(input: { title: string; body: string; author: string }): { error?: string } {
  const title = input.title.trim();
  const body = input.body.trim();
  const author = input.author.trim() || "Guest";
  if (title.length < 4) return { error: "Give the thread a title." };
  if (title.length > 90) return { error: "Keep the title under 90 characters." };
  if (body.length < 8) return { error: "Write a little more so people can reply." };
  if (body.length > 500) return { error: "Keep the post under 500 characters." };
  if (author.length > 32) return { error: "Name must be under 32 characters." };
  const thread: Thread = {
    id: `${Date.now()}`,
    title,
    body,
    author,
    at: Date.now(),
    replies: [],
  };
  writeJson(THREADS_KEY, [thread, ...loadThreads()].slice(0, 40));
  return {};
}

export function addReply(threadId: string, input: { author: string; body: string }): { error?: string } {
  const body = input.body.trim();
  const author = input.author.trim() || "Guest";
  if (body.length < 2) return { error: "Write a reply first." };
  if (body.length > 400) return { error: "Replies stay under 400 characters." };
  if (author.length > 32) return { error: "Name must be under 32 characters." };
  const threads = loadThreads();
  const index = threads.findIndex((thread) => thread.id === threadId);
  if (index < 0) return { error: "That thread is gone." };
  const reply: ThreadReply = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    author,
    body,
    at: Date.now(),
  };
  const current = threads[index];
  const next = [...threads];
  next[index] = { ...current, replies: [...current.replies, reply].slice(-30) };
  writeJson(THREADS_KEY, next);
  return {};
}
