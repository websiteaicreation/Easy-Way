import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";

async function ensureProfile(sql: Sql, userId: string) {
  const named = await sql<{ name: string }>`select name from "user" where id = ${userId}`;
  const display = named[0]?.name ?? "Member";
  await sql`
    insert into profiles (user_id, display_name)
    values (${userId}, ${display})
    on conflict (user_id) do nothing
  `;
}

async function roleFor(sql: Sql, userId: string) {
  await ensureProfile(sql, userId);
  const rows = await sql<{ role: string }>`select role from profiles where user_id = ${userId}`;
  return rows[0]?.role ?? "member";
}

async function videoId(sql: Sql, slug: string) {
  const rows = await sql<{ id: number }>`select id from videos where slug = ${slug}`;
  return rows[0]?.id ?? null;
}

const REACTION = new Set(["like", "favorite"]);
const REPORT_STATUS = new Set(["reviewed", "dismissed", "removed"]);
const VERIFY_STATUS = new Set(["verified", "rejected"]);

export const myLibrary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const role = await roleFor(sql, context.userId);
    const likes = await sql<{ slug: string }>`
      select v.slug from likes l
      join videos v on v.id = l.video_id
      where l.user_id = ${context.userId}
    `;
    const favorites = await sql<{ slug: string }>`
      select v.slug from favorites f
      join videos v on v.id = f.video_id
      where f.user_id = ${context.userId}
    `;
    const subscriptions = await sql<{ slug: string }>`
      select c.slug from subscriptions s
      join creators c on c.id = s.creator_id
      where s.user_id = ${context.userId}
    `;
    return {
      role,
      likes: likes.map((row) => row.slug),
      favorites: favorites.map((row) => row.slug),
      subscriptions: subscriptions.map((row) => row.slug),
    };
  });

export const setReaction = createServerFn({ method: "POST" })
  .validator((input: { slug: string; kind: "like" | "favorite"; on: boolean }) => {
    if (!REACTION.has(input.kind) || typeof input.slug !== "string" || typeof input.on !== "boolean") {
      throw new Error("Invalid reaction.");
    }
    return { slug: input.slug, kind: input.kind, on: input.on };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const id = await videoId(sql, data.slug);
    if (!id) return { ok: false as const, error: "That video is not in the library." };
    if (data.kind === "like") {
      if (data.on) {
        await sql`
          insert into likes (user_id, video_id) values (${context.userId}, ${id})
          on conflict do nothing
        `;
      } else {
        await sql`delete from likes where user_id = ${context.userId} and video_id = ${id}`;
      }
    } else if (data.kind === "favorite") {
      if (data.on) {
        await sql`
          insert into favorites (user_id, video_id) values (${context.userId}, ${id})
          on conflict do nothing
        `;
      } else {
        await sql`delete from favorites where user_id = ${context.userId} and video_id = ${id}`;
      }
    } else {
      return { ok: false as const, error: "Unknown reaction." };
    }
    return { ok: true as const };
  });

export const setSubscription = createServerFn({ method: "POST" })
  .validator((input: { slug: string; on: boolean }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const creators = await sql<{ id: number }>`select id from creators where slug = ${data.slug}`;
    const id = creators[0]?.id;
    if (!id) return { ok: false as const, error: "That creator is not in the library." };
    if (data.on) {
      await sql`
        insert into subscriptions (user_id, creator_id)
        values (${context.userId}, ${id})
        on conflict do nothing
      `;
    } else {
      await sql`delete from subscriptions where user_id = ${context.userId} and creator_id = ${id}`;
    }
    return { ok: true as const };
  });

export const listDbComments = createServerFn({ method: "GET" })
  .validator((slug: string) => slug)
  .handler(async ({ data: slug }) => {
    const sql = await getSql();
    return sql<{ id: number; user: string; body: string; at: string }>`
      select c.id, coalesce(p.display_name, 'Member') as user, c.body, c.created_at::text as at
      from comments c
      join videos v on v.id = c.video_id
      left join profiles p on p.user_id = c.user_id
      where v.slug = ${slug}
      order by c.created_at desc
      limit 50
    `;
  });

export const addDbComment = createServerFn({ method: "POST" })
  .validator((input: { slug: string; body: string }) => ({
    slug: input.slug,
    body: input.body.trim(),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (data.body.length < 2) return { ok: false as const, error: "Write a comment first." };
    if (data.body.length > 400) return { ok: false as const, error: "Comments stay under 400 characters." };
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const id = await videoId(sql, data.slug);
    if (!id) return { ok: false as const, error: "That video is not in the library." };
    await sql`
      insert into comments (user_id, video_id, body)
      values (${context.userId}, ${id}, ${data.body})
    `;
    return { ok: true as const };
  });

export const addDbReport = createServerFn({ method: "POST" })
  .validator((input: { slug: string; target: string; reason: string; details: string }) => ({
    slug: input.slug.trim(),
    target: input.target.trim().slice(0, 120),
    reason: input.reason.trim(),
    details: input.details.trim(),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (!data.reason) return { ok: false as const, error: "Choose a reason." };
    if (data.target.length < 2) return { ok: false as const, error: "Say what you are reporting." };
    if (data.details.length < 8) return { ok: false as const, error: "Add a few details so a moderator could act." };
    if (data.details.length > 500) return { ok: false as const, error: "Keep the note under 500 characters." };
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const id = data.slug ? await videoId(sql, data.slug) : null;
    await sql`
      insert into reports (user_id, video_id, target, reason, details)
      values (${context.userId}, ${id}, ${data.target}, ${data.reason}, ${data.details})
    `;
    return { ok: true as const };
  });

export const adminQueue = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const role = await roleFor(sql, context.userId);
    if (role !== "admin") return { ok: false as const, error: "Administrators only." };
    const reports = await sql<{
      id: number;
      target: string;
      reason: string;
      details: string;
      status: string;
      at: string;
    }>`
      select id, target, reason, details, status, created_at::text as at
      from reports
      order by created_at desc
      limit 40
    `;
    const creators = await sql<{ id: number; name: string; slug: string; verified: boolean }>`
      select id, name, slug, verified from creators order by name
    `;
    return { ok: true as const, reports, creators };
  });

export const moderateReport = createServerFn({ method: "POST" })
  .validator((input: { id: number; action: "reviewed" | "dismissed" | "removed"; note: string }) => {
    if (!REPORT_STATUS.has(input.action) || typeof input.id !== "number") {
      throw new Error("Invalid moderation action.");
    }
    return { id: input.id, action: input.action, note: String(input.note ?? "") };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await roleFor(sql, context.userId);
    if (role !== "admin") return { ok: false as const, error: "Administrators only." };
    await sql`
      update reports set status = ${data.action}
      where id = ${data.id}
    `;
    await sql`
      insert into moderation_actions (report_id, admin_user_id, action, note)
      values (${data.id}, ${context.userId}, ${data.action}, ${data.note.slice(0, 240)})
    `;
    return { ok: true as const };
  });

export const verifyCreator = createServerFn({ method: "POST" })
  .validator((input: { id: number; status: "verified" | "rejected"; note: string }) => {
    if (!VERIFY_STATUS.has(input.status) || typeof input.id !== "number") {
      throw new Error("Invalid verification.");
    }
    return { id: input.id, status: input.status, note: String(input.note ?? "") };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const role = await roleFor(sql, context.userId);
    if (role !== "admin") return { ok: false as const, error: "Administrators only." };
    await sql`
      update creators set verified = ${data.status === "verified"}
      where id = ${data.id}
    `;
    await sql`
      insert into verification_records (creator_id, status, decided_by, note)
      values (${data.id}, ${data.status}, ${context.userId}, ${data.note.slice(0, 240)})
    `;
    return { ok: true as const };
  });
