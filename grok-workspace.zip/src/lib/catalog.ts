export const CATEGORIES = [
  "Lesbian",
  "18-25",
  "MILF",
  "Popular With Women",
  "Anal",
  "Threesome",
  "Mature",
  "Hentai",
  "Ebony",
  "Japanese",
] as const;

export type Category = (typeof CATEGORIES)[number];

export const ARTS = ["amber", "rose", "violet", "green", "blue", "gold"] as const;
export type Art = (typeof ARTS)[number];

export type ShelfKind = "video" | "clip" | "short" | "gif" | "photo";

export type Video = {
  slug: string;
  title: string;
  creator: string;
  category: Category;
  views: string;
  viewsNum: number;
  duration: string;
  durationSec: number;
  time: number;
  art: Art;
  synopsis: string;
  local?: boolean;
  kind?: ShelfKind;
  featured?: boolean;
  region?: "morocco";
};

export type CreatorProfile = {
  slug: string;
  name: string;
  place: string;
  bio: string;
  art: Art;
};

export const CREATORS: CreatorProfile[] = [
  {
    slug: "mila-studio",
    name: "Mila Studio",
    place: "Marrakech",
    bio: "Diary films about city light, riads, and the rooms people actually live in.",
    art: "amber",
  },
  {
    slug: "northlight",
    name: "Northlight",
    place: "Montreal",
    bio: "Illustrated loops and paced clips. The set comes down before anyone calls it finished.",
    art: "rose",
  },
  {
    slug: "studio-june",
    name: "Studio June",
    place: "Tokyo",
    bio: "Short films about affection, distance, and the conversations that happen after midnight.",
    art: "violet",
  },
  {
    slug: "lena-moves",
    name: "Lena Moves",
    place: "Austin",
    bio: "Shorties and slow mornings, filmed for people who want the quiet version.",
    art: "green",
  },
  {
    slug: "easy-way-originals",
    name: "Easy Way Originals",
    place: "Remote",
    bio: "Interviews and photo sets with creators who publish for adult audiences.",
    art: "blue",
  },
  {
    slug: "the-sunday-set",
    name: "The Sunday Set",
    place: "London",
    bio: "Small-cast nights. Three people, one table, and a rule that everyone speaks first.",
    art: "gold",
  },
];

export const CATALOG: Video[] = [
  {
    slug: "a-weekend-in-the-city-creator-diary",
    title: "A Weekend in the City — Together",
    creator: "Mila Studio",
    category: "Lesbian",
    views: "248K",
    viewsNum: 248000,
    duration: "12:48",
    durationSec: 768,
    time: 6,
    art: "amber",
    featured: true,
    region: "morocco",
    synopsis:
      "Two women share a Saturday market, a late train, and one apartment. A diary about pace, not spectacle.",
  },
  {
    slug: "behind-the-scenes-a-creative-day",
    title: "Slow, and On Her Terms",
    creator: "Northlight",
    category: "Anal",
    views: "192K",
    viewsNum: 192000,
    duration: "08:16",
    durationSec: 496,
    time: 5,
    art: "rose",
    kind: "clip",
    synopsis:
      "A paced clip about checking in, slowing down, and stopping the moment someone asks. Consent stays in the frame.",
  },
  {
    slug: "a-little-romance-short-film",
    title: "After Class, Before Midnight",
    creator: "Studio June",
    category: "18-25",
    views: "184K",
    viewsNum: 184000,
    duration: "18:03",
    durationSec: 1083,
    time: 4,
    art: "violet",
    featured: true,
    synopsis:
      "Two adults share a booth, a missed train, and one honest conversation. A short film staged like a letter.",
  },
  {
    slug: "morning-movement-and-wellness",
    title: "The Morning She Stayed",
    creator: "Lena Moves",
    category: "Popular With Women",
    views: "96K",
    viewsNum: 96000,
    duration: "09:42",
    durationSec: 582,
    time: 3,
    art: "green",
    synopsis:
      "A slow morning between partners: light, breath, and no rush to leave the room. Built for women who want the quiet version.",
  },
  {
    slug: "the-after-hours-interview",
    title: "Unhurried — After Hours",
    creator: "Easy Way Originals",
    category: "Mature",
    views: "87K",
    viewsNum: 87000,
    duration: "22:11",
    durationSec: 1331,
    time: 2,
    art: "blue",
    featured: true,
    synopsis:
      "A long conversation with a creator who publishes on her own clock. Boundaries, schedules, and what she wishes she knew earlier.",
  },
  {
    slug: "two-truths-and-a-story",
    title: "Three at the Table",
    creator: "The Sunday Set",
    category: "Threesome",
    views: "76K",
    viewsNum: 76000,
    duration: "06:35",
    durationSec: 395,
    time: 1,
    art: "gold",
    synopsis:
      "Three adults decide, out loud, what they want from the night. Nobody is the punchline.",
  },
  {
    slug: "a-quiet-evening-creator-diary",
    title: "The Evening She Kept",
    creator: "Mila Studio",
    category: "MILF",
    views: "65K",
    viewsNum: 65000,
    duration: "14:20",
    durationSec: 860,
    time: 7,
    art: "rose",
    featured: true,
    synopsis:
      "Cooking for one, notes for tomorrow’s shoot, and a window left open. An older creator’s evening, kept close.",
  },
  {
    slug: "making-the-set-studio-notes",
    title: "Ink After Dark",
    creator: "Northlight",
    category: "Hentai",
    views: "58K",
    viewsNum: 58000,
    duration: "04:12",
    durationSec: 252,
    time: 8,
    art: "violet",
    kind: "clip",
    synopsis:
      "An illustrated short. Abstract frames and ink, no live actors, cut like a studio note.",
  },
  {
    slug: "a-sunday-reset-home-and-habits",
    title: "Golden Hour in the Riad",
    creator: "Mila Studio",
    category: "Ebony",
    views: "51K",
    viewsNum: 51000,
    duration: "07:52",
    durationSec: 472,
    time: 9,
    art: "amber",
    featured: true,
    region: "morocco",
    synopsis:
      "Studio light in a Marrakech riad. A portrait session held at the warmest hour of the day.",
  },
  {
    slug: "the-art-of-the-short-film",
    title: "Tokyo, After the Train",
    creator: "Studio June",
    category: "Japanese",
    views: "43K",
    viewsNum: 43000,
    duration: "16:24",
    durationSec: 984,
    time: 10,
    art: "rose",
    synopsis:
      "June breaks down blocking, silence, and why the film ends one line earlier than expected.",
  },
  {
    slug: "stretch-breathe-recharge",
    title: "Riad Glow",
    creator: "Lena Moves",
    category: "18-25",
    views: "39K",
    viewsNum: 39000,
    duration: "00:46",
    durationSec: 46,
    time: 11,
    art: "green",
    kind: "short",
    region: "morocco",
    synopsis: "A shorty from a riad courtyard. One look back, then the light changes.",
  },
  {
    slug: "creator-q-and-a-getting-started",
    title: "Still, Set One",
    creator: "Easy Way Originals",
    category: "Ebony",
    views: "31K",
    viewsNum: 31000,
    duration: "00:12",
    durationSec: 12,
    time: 12,
    art: "blue",
    kind: "photo",
    synopsis: "A photo set. One still, held. No clip attached — the card is the picture.",
  },
  {
    slug: "atlas-light-clip",
    title: "Atlas Light",
    creator: "Mila Studio",
    category: "MILF",
    views: "44K",
    viewsNum: 44000,
    duration: "03:20",
    durationSec: 200,
    time: 13,
    art: "gold",
    kind: "clip",
    region: "morocco",
    synopsis: "A three-minute clip shot against the High Atlas at dusk. Close, calm, and fully agreed.",
  },
  {
    slug: "three-count-shorty",
    title: "Three Count",
    creator: "The Sunday Set",
    category: "Threesome",
    views: "28K",
    viewsNum: 28000,
    duration: "00:38",
    durationSec: 38,
    time: 14,
    art: "gold",
    kind: "short",
    synopsis: "A shorty: three people, one countdown, and a laugh before anyone moves.",
  },
  {
    slug: "amber-loop",
    title: "Amber Loop",
    creator: "Lena Moves",
    category: "Popular With Women",
    views: "22K",
    viewsNum: 22000,
    duration: "00:06",
    durationSec: 6,
    time: 15,
    art: "amber",
    kind: "gif",
    region: "morocco",
    synopsis: "A looping GIF. Warm light, a turn of the shoulder, then it starts again.",
  },
  {
    slug: "ink-loop",
    title: "Ink Loop",
    creator: "Northlight",
    category: "Hentai",
    views: "19K",
    viewsNum: 19000,
    duration: "00:08",
    durationSec: 8,
    time: 16,
    art: "violet",
    kind: "gif",
    synopsis: "An ink loop. Line, blush, line. Illustrated only.",
  },
  {
    slug: "window-light-still",
    title: "Window Light Still",
    creator: "Studio June",
    category: "Japanese",
    views: "17K",
    viewsNum: 17000,
    duration: "00:10",
    durationSec: 10,
    time: 17,
    art: "rose",
    kind: "photo",
    synopsis: "A single window-light still from the Tokyo set. Nothing moves.",
  },
  {
    slug: "marrakech-heat",
    title: "Marrakech Heat",
    creator: "Mila Studio",
    category: "Lesbian",
    views: "121K",
    viewsNum: 121000,
    duration: "11:05",
    durationSec: 665,
    time: 18,
    art: "rose",
    featured: true,
    region: "morocco",
    synopsis: "Hottest in Morocco this week. A riad, two women, and the fan that never quite keeps up.",
  },
];

export const SEED_COMMENTS: Record<string, { user: string; text: string }[]> = {
  "a-weekend-in-the-city-creator-diary": [
    { user: "Nora", text: "The market audio feels close without being noisy. Lovely pacing." },
    { user: "Evan", text: "That train window shot is the one I keep rewinding." },
  ],
  "a-little-romance-short-film": [
    { user: "Hana", text: "They let the silence sit. More films should trust that." },
    { user: "Chris", text: "The booth lighting is doing half the acting. In a good way." },
  ],
  "the-after-hours-interview": [
    { user: "Priya", text: "The section on schedules is the most useful thing I have watched this month." },
  ],
  "morning-movement-and-wellness": [
    { user: "Jules", text: "Did this with the sound low. The quiet is exactly long enough." },
  ],
};

const ART_FOR: Record<Category, Art> = {
  Lesbian: "rose",
  "18-25": "amber",
  MILF: "gold",
  "Popular With Women": "violet",
  Anal: "blue",
  Threesome: "green",
  Mature: "amber",
  Hentai: "violet",
  Ebony: "gold",
  Japanese: "rose",
};

export function artForCategory(category: Category): Art {
  return ART_FOR[category];
}

export function getCatalogVideo(slug: string): Video | undefined {
  return CATALOG.find((video) => video.slug === slug);
}

export function creatorProfile(name: string): CreatorProfile | undefined {
  return CREATORS.find((creator) => creator.name === name);
}

export function getCreator(slug: string): CreatorProfile | undefined {
  return CREATORS.find((creator) => creator.slug === slug);
}

export function slugify(title: string): string {
  const base = title
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 72);
  return base || "video";
}

export function parseDuration(value: string): number | null {
  const match = /^(\d{1,3}):([0-5]\d)$/.exec(value.trim());
  if (!match) return null;
  const minutes = Number(match[1]);
  const seconds = Number(match[2]);
  if (minutes > 180) return null;
  if (minutes === 0 && seconds === 0) return null;
  return minutes * 60 + seconds;
}

export function formatClock(total: number): string {
  const safe = Math.max(0, Math.floor(total));
  const minutes = Math.floor(safe / 60);
  const seconds = safe % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export function chipLabel(category: string): string {
  if (category === "All") return "All videos";
  if (category === "Saved") return "Playlists";
  return category;
}

export function relatedVideos(videos: Video[], current: Video, limit = 5): Video[] {
  const others = videos.filter((video) => video.slug !== current.slug);
  const close = others.filter(
    (video) => video.category === current.category || video.creator === current.creator,
  );
  const rest = others.filter((video) => !close.includes(video));
  return [...close, ...rest].slice(0, limit);
}