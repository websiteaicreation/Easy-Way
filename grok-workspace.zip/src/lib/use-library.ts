import { useEffect, useMemo, useState } from "react";
import { CATALOG, type Video } from "@/lib/catalog";
import {
  LIBRARY_EVENT,
  loadFollows,
  loadLikes,
  loadMemberName,
  loadSaved,
  loadUploads,
  toggleFollow,
  toggleLike,
  toggleSaved,
} from "@/lib/library";

export function useLibrary() {
  const [uploads, setUploads] = useState<Video[]>([]);
  const [saved, setSaved] = useState<string[]>([]);
  const [likes, setLikes] = useState<string[]>([]);
  const [follows, setFollows] = useState<string[]>([]);
  const [memberName, setMemberName] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sync = () => {
      setUploads(loadUploads());
      setSaved(loadSaved());
      setLikes(loadLikes());
      setFollows(loadFollows());
      setMemberName(loadMemberName());
      setReady(true);
    };
    sync();
    window.addEventListener(LIBRARY_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(LIBRARY_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const videos = useMemo(() => {
    const slugs = new Set(uploads.map((video) => video.slug));
    return [...uploads, ...CATALOG.filter((video) => !slugs.has(video.slug))];
  }, [uploads]);

  return {
    videos,
    uploads,
    saved,
    likes,
    follows,
    memberName,
    ready,
    isSaved: (slug: string) => saved.includes(slug),
    isLiked: (slug: string) => likes.includes(slug),
    toggleSaved: (slug: string) => {
      toggleSaved(slug);
    },
    toggleLike: (slug: string) => {
      toggleLike(slug);
    },
    toggleFollow: (slug: string) => {
      toggleFollow(slug);
    },
  };
}
