import { create } from "zustand";

export type SortKey = "popular" | "newest" | "short";

export type Lane =
  | "all"
  | "featured"
  | "clips"
  | "shorties"
  | "recommended"
  | "morocco"
  | "gifs"
  | "photos";

type BrowseState = {
  query: string;
  category: string;
  lane: Lane;
  sort: SortKey;
  page: number;
  setQuery: (query: string) => void;
  setCategory: (category: string) => void;
  setLane: (lane: Lane) => void;
  setSort: (sort: SortKey) => void;
  setPage: (page: number) => void;
};

function sortFor(lane: Lane): SortKey {
  if (lane === "shorties" || lane === "clips") return "short";
  if (lane === "recommended") return "newest";
  return "popular";
}

export const useBrowse = create<BrowseState>((set) => ({
  query: "",
  category: "All",
  lane: "all",
  sort: "popular",
  page: 1,
  setQuery: (query) => set({ query, page: 1 }),
  setCategory: (category) => set({ category, lane: "all", page: 1 }),
  setLane: (lane) => set({ lane, category: "All", page: 1, sort: sortFor(lane) }),
  setSort: (sort) => set({ sort, page: 1 }),
  setPage: (page) => set({ page }),
}));
