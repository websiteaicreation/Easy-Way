import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Menu, Plus, Search, UserRound, X } from "lucide-react";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { CategoryDrawer } from "@/components/category-drawer";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useBrowse } from "@/lib/browse";

const ToastContext = createContext<(message: string) => void>(() => {});

export function useToast() {
  return useContext(ToastContext);
}

const AGE_KEY = "afterdark18";

export function Shell({ children }: { children: ReactNode }) {
  const [phase, setPhase] = useState<"ask" | "in" | "deny">("ask");
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState(true);
  const [toast, setToast] = useState("");
  const [toastOn, setToastOn] = useState(false);
  const query = useBrowse((state) => state.query);
  const setQuery = useBrowse((state) => state.setQuery);
  const [draft, setDraft] = useState(query);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();

  useEffect(() => {
    setDraft(query);
  }, [query]);

  useEffect(() => {
    try {
      if (localStorage.getItem(AGE_KEY) === "yes" || document.documentElement.dataset.ad === "in") {
        document.documentElement.dataset.ad = "in";
        setPhase("in");
      }
    } catch {
      if (document.documentElement.dataset.ad === "in") setPhase("in");
    }
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  function showToast(message: string) {
    setToast(message);
    setToastOn(true);
    window.setTimeout(() => setToastOn(false), 2600);
  }

  function enter() {
    document.documentElement.dataset.ad = "in";
    try {
      localStorage.setItem(AGE_KEY, "yes");
    } catch {
      /* storage can be blocked; the gate still closes for this view */
    }
    setPhase("in");
  }

  function onSearch(event: FormEvent) {
    event.preventDefault();
    setQuery(draft.trim());
    setMenuOpen(false);
    if (pathname !== "/") {
      void navigate({ to: "/", hash: "discover" });
      return;
    }
    document.getElementById("discover")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <ToastContext.Provider value={showToast}>
      <div className="app-frame">
        <div className="utilitybar">
          <Link to="/studio">CREATOR TOOLS</Link>
          <Link to="/blog">STORIES</Link>
          <Link to="/community">COMMUNITY</Link>
          <Link to="/insights">INSIGHTS</Link>
          <Link to="/safety">TRUST & SAFETY</Link>
          <span className="language">EN</span>
        </div>
        <header className="topbar">
          <button
            className="icon-btn"
            type="button"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <Link className="brand" to="/" activeOptions={{ exact: true, includeHash: false }}>
            Easy <span>Way</span>
          </Link>
          <form className="search" onSubmit={onSearch}>
            <input
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="Search videos and creators"
              aria-label="Search videos and creators"
            />
            <button type="submit" aria-label="Search">
              <Search size={18} />
            </button>
          </form>
          <Link className="header-action" to="/studio" title="Creator studio" aria-label="Creator studio">
            <Plus size={22} />
          </Link>
          <Link
            className="header-action"
            to={isPending || user ? "/account" : "/login"}
            title={user ? "Your library" : "Sign in"}
            aria-label={user ? "Your library" : "Sign in"}
          >
            <UserRound size={20} />
          </Link>
        </header>
        <nav className="mainnav" id="mainNav" aria-label="Primary">
          <Link to="/" activeOptions={{ exact: true, includeHash: true }}>
            HOME
          </Link>
          <Link to="/" hash="discover">
            VIDEOS
          </Link>
          <button type="button" onClick={() => setMenuOpen(true)}>
            CATEGORIES
          </button>
          <Link to="/" hash="creators">
            CREATORS
          </Link>
          <Link to="/studio" activeOptions={{ exact: true }}>
            CREATOR STUDIO
          </Link>
          <Link to="/safety" activeOptions={{ exact: true }}>
            TRUST & SAFETY
          </Link>
        </nav>
        <CategoryDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onToast={showToast} />
        {pathname === "/" && notice ? (
          <div className="container">
            <div className="notice">
              <span>
                You are browsing Easy Way in English.{" "}
                <Link to="/safety" hash="standards">
                  Learn about our community.
                </Link>
              </span>
              <button type="button" aria-label="Dismiss notice" onClick={() => setNotice(false)}>
                <X size={18} />
              </button>
            </div>
          </div>
        ) : null}
        <div className="page">{children}</div>
        <footer className="site-footer" id="about">
          <div className="footer-brand">
            <Link className="brand" to="/">
              Easy <span>Way</span>
            </Link>
            <p>Adult-only discovery demo. Built around consent, safety, and creator rights.</p>
          </div>
          <div>
            <b>Explore</b>
            <Link to="/" hash="discover">
              Trending
            </Link>
            <button type="button" onClick={() => setMenuOpen(true)}>
              Categories
            </button>
            <Link to="/" hash="creators">
              Creators
            </Link>
          </div>
          <div>
            <b>Safety</b>
            <Link to="/safety">Trust & Safety</Link>
            <Link to="/safety" hash="report">
              Report content
            </Link>
            <Link to="/safety" hash="copyright">
              Copyright & takedowns
            </Link>
          </div>
          <div>
            <b>Information</b>
            <Link to="/safety" hash="privacy">
              Privacy
            </Link>
            <Link to="/safety" hash="terms">
              Terms
            </Link>
            <a href="mailto:hello@example.com">Contact</a>
          </div>
          <div className="copyright">
            © 2026 Easy Way. Demo concept — sample cards use abstract art, not explicit media. Replace
            contact details and policies before any real launch.
          </div>
        </footer>
      </div>
      <div className="gate" hidden={phase === "in"}>
        {phase === "deny" ? (
          <div className="gate-card">
            <h1>Access denied</h1>
            <p>You must be at least 18 to enter this demo.</p>
          </div>
        ) : (
          <div className="gate-card">
            <div className="brand large">
              Easy <span>Way</span>
            </div>
            <p className="eyebrow">ADULTS ONLY · 18+</p>
            <h1>Are you 18 or older?</h1>
            <p>
              This demo is intended only for adults. By entering, you confirm that you are at least 18 and
              that viewing adult-oriented material is legal where you live.
            </p>
            <button className="btn primary" type="button" data-age-enter onClick={enter}>
              I am 18 or older — Enter
            </button>
            <button className="btn ghost" type="button" onClick={() => setPhase("deny")}>
              I am under 18 — Exit
            </button>
            <small>Demo interface only. Sample cards use abstract placeholders, not explicit media.</small>
          </div>
        )}
      </div>
      <div className={toastOn ? "toast show" : "toast"} role="status">
        {toast}
      </div>
    </ToastContext.Provider>
  );
}
