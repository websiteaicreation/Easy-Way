import { Pause, Play } from "lucide-react";
import { useEffect, useState } from "react";
import { formatClock, type Video } from "@/lib/catalog";

export function Player({ video }: { video: Video }) {
  const [playing, setPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    setPlaying(false);
    setElapsed(0);
  }, [video.slug]);

  useEffect(() => {
    if (!playing) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const delta = (now - last) / 1000;
      last = now;
      setElapsed((current) => {
        const next = current + delta * (video.durationSec / 36);
        if (next >= video.durationSec) {
          setPlaying(false);
          return video.durationSec;
        }
        return next;
      });
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing, video.durationSec]);

  return (
    <div className="player">
      <button
        type="button"
        className={playing ? "player-stage is-playing" : "player-stage"}
        aria-label={playing ? `Pause ${video.title}` : `Play preview of ${video.title}`}
        onClick={() => {
          if (elapsed >= video.durationSec) setElapsed(0);
          setPlaying((value) => !value);
        }}
      >
        <span className={`thumb-art art-${video.art}`} aria-hidden="true">
          <span className="shape" />
        </span>
        <span className="tag">{video.category.toUpperCase()}</span>
        <span className="play">
          {playing ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" />}
        </span>
        <span className="player-caption">Abstract preview — this demo does not stream a video file.</span>
      </button>
      <div className="scrub">
        <span>{formatClock(elapsed)}</span>
        <input
          type="range"
          min={0}
          max={video.durationSec}
          step={1}
          value={Math.min(video.durationSec, Math.floor(elapsed))}
          aria-label="Preview timeline"
          onChange={(event) => {
            setElapsed(Number(event.target.value));
            setPlaying(false);
          }}
        />
        <span>{video.duration}</span>
      </div>
    </div>
  );
}
