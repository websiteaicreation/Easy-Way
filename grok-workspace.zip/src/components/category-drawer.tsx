import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  BadgeCheck,
  BarChart3,
  Camera,
  ChevronDown,
  Clapperboard,
  Flame,
  Newspaper,
  Play,
  Scissors,
  Shield,
  Star,
  ThumbsUp,
  Tv,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { type Lane, useBrowse } from "@/lib/browse";
import { CATEGORIES, CREATORS } from "@/lib/catalog";

export function CategoryDrawer({
  open,
  onClose,
  onToast,
}: {
  open: boolean;
  onClose: () => void;
  onToast: (message: string) => void;
}) {
  const [modelsOpen, setModelsOpen] = useState(false);
  const [channelsOpen, setChannelsOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(true);
  const [communityOpen, setCommunityOpen] = useState(false);
  const category = useBrowse((state) => state.category);
  const lane = useBrowse((state) => state.lane);
  const setCategory = useBrowse((state) => state.setCategory);
  const setLane = useBrowse((state) => state.setLane);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const navigate = useNavigate();
  const [top, setTop] = useState(92);

  useEffect(() => {
    function place() {
      const bar = document.querySelector(".topbar");
      if (!bar) return;
      setTop(bar.getBoundingClientRect().bottom);
    }
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, { passive: true });
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  function go(apply: () => void) {
    apply();
    onClose();
    if (pathname !== "/") {
      void navigate({ to: "/", hash: "discover" });
      return;
    }
    document.getElementById("discover")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function pickLane(next: Lane) {
    go(() => setLane(next));
  }

  return (
    <div className={open ? "drawer-root open" : "drawer-root"} hidden={!open} style={{ top }}>
      <button type="button" className="drawer-backdrop" aria-label="Close menu" onClick={onClose} />
      <aside className="drawer" aria-label="Categories" aria-hidden={!open}>
        <Link className="drawer-program" to="/studio" onClick={onClose}>
          <BadgeCheck size={18} />
          <span>Join the Easy Way Creator Program</span>
        </Link>

        <button
          type="button"
          className={lane === "featured" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("featured")}
        >
          <Clapperboard size={18} />
          <span>Featured Videos</span>
        </button>
        <button
          type="button"
          className={lane === "clips" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("clips")}
        >
          <Scissors size={18} />
          <span>Clips</span>
        </button>
        <button
          type="button"
          className={lane === "shorties" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("shorties")}
        >
          <Play size={18} />
          <span>Shorties</span>
        </button>
        <button
          type="button"
          className={lane === "recommended" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("recommended")}
        >
          <ThumbsUp size={18} />
          <span>Recommended Videos</span>
        </button>
        <button
          type="button"
          className={lane === "morocco" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("morocco")}
        >
          <Flame size={18} />
          <span>Hottest In Morocco</span>
          <Star className="drawer-hot" size={14} fill="currentColor" aria-hidden="true" />
        </button>

        <button
          type="button"
          className="drawer-row"
          aria-expanded={modelsOpen}
          onClick={() => setModelsOpen((value) => !value)}
        >
          <Star size={18} />
          <span>Pornstars & Models</span>
          <ChevronDown className={modelsOpen ? "chev open" : "chev"} size={18} />
        </button>
        {modelsOpen ? (
          <div className="drawer-sub">
            {CREATORS.map((creator) => (
              <Link
                key={creator.slug}
                className="drawer-row sub"
                to="/creator/$slug"
                params={{ slug: creator.slug }}
                onClick={onClose}
              >
                <span className={`model-dot art-${creator.art}`} aria-hidden="true" />
                <span>{creator.name}</span>
              </Link>
            ))}
          </div>
        ) : null}

        <button
          type="button"
          className="drawer-row"
          aria-expanded={channelsOpen}
          onClick={() => setChannelsOpen((value) => !value)}
        >
          <Tv size={18} />
          <span>Channels</span>
          <ChevronDown className={channelsOpen ? "chev open" : "chev"} size={18} />
        </button>
        {channelsOpen ? (
          <div className="drawer-sub">
            {CREATORS.map((creator) => (
              <Link
                key={creator.slug}
                className="drawer-row sub"
                to="/creator/$slug"
                params={{ slug: creator.slug }}
                onClick={onClose}
              >
                <Tv size={16} />
                <span>{creator.name}</span>
              </Link>
            ))}
          </div>
        ) : null}

        <button
          type="button"
          className="drawer-row"
          aria-expanded={categoriesOpen}
          onClick={() => setCategoriesOpen((value) => !value)}
        >
          <Clapperboard size={18} />
          <span>Top Categories</span>
          <ChevronDown className={categoriesOpen ? "chev open" : "chev"} size={18} />
        </button>
        {categoriesOpen ? (
          <div className="drawer-sub">
            {CATEGORIES.map((item) => (
              <button
                key={item}
                type="button"
                className={category === item && lane === "all" ? "drawer-row sub active" : "drawer-row sub"}
                onClick={() => go(() => setCategory(item))}
              >
                <Clapperboard size={16} />
                <span>{item}</span>
              </button>
            ))}
            <button
              type="button"
              className="drawer-all"
              onClick={() => {
                setCategory("All");
                onClose();
                if (pathname !== "/") {
                  void navigate({ to: "/", hash: "categories" });
                  return;
                }
                document.getElementById("categories")?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
            >
              All Categories
            </button>
          </div>
        ) : null}

        <button
          type="button"
          className={category === "Saved" ? "drawer-row active" : "drawer-row"}
          onClick={() => go(() => setCategory("Saved"))}
        >
          <Clapperboard size={18} />
          <span>Playlists</span>
        </button>
        <button
          type="button"
          className={lane === "gifs" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("gifs")}
        >
          <span className="gif-mark">GIF</span>
          <span>Porn GIFs</span>
        </button>
        <button
          type="button"
          className={lane === "photos" ? "drawer-row active" : "drawer-row"}
          onClick={() => pickLane("photos")}
        >
          <Camera size={18} />
          <span>Photos</span>
        </button>

        <button
          type="button"
          className="drawer-row"
          aria-expanded={communityOpen}
          onClick={() => setCommunityOpen((value) => !value)}
        >
          <Users size={18} />
          <span>Community</span>
          <ChevronDown className={communityOpen ? "chev open" : "chev"} size={18} />
        </button>
        {communityOpen ? (
          <div className="drawer-sub">
            <Link className="drawer-row sub" to="/safety" hash="standards" onClick={onClose}>
              <span>Guidelines</span>
            </Link>
            <Link className="drawer-row sub" to="/safety" hash="report" onClick={onClose}>
              <span>Report content</span>
            </Link>
            <Link className="drawer-row sub" to="/community" onClick={onClose}>
              <span>Discussions</span>
            </Link>
          </div>
        ) : null}

        <Link className="drawer-cta" to="/membership" onClick={onClose}>
          Get Full Easy Way Membership
        </Link>

        <div className="drawer-grid">
          <Link to="/safety" className="drawer-mini" onClick={onClose}>
            <Shield size={18} />
            <span>Trust & Safety</span>
          </Link>
          <Link to="/studio" className="drawer-mini" onClick={onClose}>
            <Clapperboard size={18} />
            <span>Studio</span>
          </Link>
          <Link to="/blog" className="drawer-mini" onClick={onClose}>
            <Newspaper size={18} />
            <span>Blog</span>
          </Link>
          <Link to="/insights" className="drawer-mini" onClick={onClose}>
            <BarChart3 size={18} />
            <span>Insights</span>
          </Link>
        </div>
      </aside>
    </div>
  );
}
