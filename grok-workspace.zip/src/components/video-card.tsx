import { Link } from "@tanstack/react-router";
import { BadgeCheck, Play } from "lucide-react";
import type { Video } from "@/lib/catalog";

export function Thumb({ video }: { video: Video }) {
  return (
    <div className="thumb">
      <div className={`thumb-art art-${video.art}`}>
        <span className="shape" />
      </div>
      <span className="tag">{video.category.toUpperCase()}</span>
      {video.local ? <span className="local-flag">YOURS</span> : null}
      <span className="play" aria-hidden="true">
        <Play size={16} fill="currentColor" />
      </span>
      <span className="duration">
        {video.kind === "photo" ? "PHOTO" : video.kind === "gif" ? "GIF" : video.duration}
      </span>
    </div>
  );
}

export function VideoCard({ video }: { video: Video }) {
  return (
    <Link
      to="/watch/$slug"
      params={{ slug: video.slug }}
      className="video-card"
      aria-label={`Open ${video.title}`}
    >
      <Thumb video={video} />
      <h3>{video.title}</h3>
      <div className="video-meta">
        <span className="creator">
          {video.creator}
          <BadgeCheck className="verified" size={12} aria-label="Verified creator" />
        </span>
        <span className="views">{video.views} views</span>
      </div>
    </Link>
  );
}

export function RelatedCard({ video }: { video: Video }) {
  return (
    <Link to="/watch/$slug" params={{ slug: video.slug }} className="related-card">
      <Thumb video={video} />
      <div>
        <h3>{video.title}</h3>
        <p>
          {video.creator} · {video.duration}
        </p>
      </div>
    </Link>
  );
}
