import { Link, createFileRoute } from "@tanstack/react-router";
import { CATEGORIES } from "@/lib/catalog";
import { useLibrary } from "@/lib/use-library";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [{ title: "Insights — Easy Way" }],
  }),
  component: InsightsPage,
});

function InsightsPage() {
  const { videos, uploads, saved, likes, follows } = useLibrary();
  const views = videos.reduce((sum, video) => sum + video.viewsNum, 0);
  const counts = CATEGORIES.map((category) => ({
    category,
    count: videos.filter((video) => video.category === category).length,
  }));
  const peak = Math.max(1, ...counts.map((row) => row.count));
  const creators = [...new Set(videos.map((video) => video.creator))].length;

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">INSIGHTS</p>
        <h1>Shelf at a glance</h1>
        <p>Counts from the sample catalog plus anything you published on this device.</p>
      </header>
      <section className="stat-row">
        <div className="stat">
          <b>{videos.length}</b>
          <span>Videos on the shelf</span>
        </div>
        <div className="stat">
          <b>{uploads.length}</b>
          <span>Published here</span>
        </div>
        <div className="stat">
          <b>{creators}</b>
          <span>Creator names</span>
        </div>
      </section>
      <section className="stat-row">
        <div className="stat">
          <b>{Math.round(views / 1000)}K</b>
          <span>Sample views</span>
        </div>
        <div className="stat">
          <b>{saved.length}</b>
          <span>Saved</span>
        </div>
        <div className="stat">
          <b>{likes.length}</b>
          <span>Likes</span>
        </div>
      </section>
      <section className="panel">
        <h2>Top categories</h2>
        {counts.map((row) => (
          <div key={row.category} className="bar-row">
            <span>{row.category}</span>
            <span className="bar-track">
              <span className="bar-fill" style={{ width: `${(row.count / peak) * 100}%` }} />
            </span>
            <b>{row.count}</b>
          </div>
        ))}
        <p className="section-kicker">Following {follows.length} {follows.length === 1 ? "creator" : "creators"} on this device.</p>
        <Link className="btn outline" to="/studio">
          Open Creator Studio
        </Link>
      </section>
    </main>
  );
}
