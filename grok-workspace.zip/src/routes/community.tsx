import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { useToast } from "@/components/shell";
import { addReply, addThread, loadThreads, type Thread } from "@/lib/library";

export const Route = createFileRoute("/community")({
  head: () => ({
    meta: [{ title: "Community — Easy Way" }],
  }),
  component: CommunityPage,
});

function whenLabel(at: number) {
  if (!at) return "Featured";
  const minutes = Math.floor((Date.now() - at) / 60_000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function CommunityPage() {
  const toast = useToast();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [author, setAuthor] = useState("Guest");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [reply, setReply] = useState("");
  const [error, setError] = useState("");

  function refresh(focus?: string) {
    const next = loadThreads();
    setThreads(next);
    if (focus) setOpenId(focus);
  }

  useEffect(() => {
    refresh();
  }, []);

  function onCreate(event: FormEvent) {
    event.preventDefault();
    const result = addThread({ title, body, author });
    if (result.error) {
      setError(result.error);
      return;
    }
    setError("");
    setTitle("");
    setBody("");
    refresh();
    toast("Thread posted on this device.");
  }

  function onReply(event: FormEvent, threadId: string) {
    event.preventDefault();
    const result = addReply(threadId, { author, body: reply });
    if (result.error) {
      setError(result.error);
      return;
    }
    setError("");
    setReply("");
    refresh(threadId);
    toast("Reply saved on this device.");
  }

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">COMMUNITY</p>
        <h1>Discussions</h1>
        <p>A local board for how sets are run. Posts stay on this device.</p>
      </header>

      <form className="panel" onSubmit={onCreate}>
        <h2>Start a thread</h2>
        <div className="split-fields">
          <label className="field">
            Name
            <input value={author} maxLength={32} onChange={(event) => setAuthor(event.target.value)} />
          </label>
          <label className="field">
            Title
            <input
              value={title}
              maxLength={90}
              placeholder="What are you asking?"
              onChange={(event) => setTitle(event.target.value)}
            />
          </label>
        </div>
        <label className="field">
          Post
          <textarea
            value={body}
            maxLength={500}
            placeholder="Keep it about the work, the set, or the shelf."
            onChange={(event) => setBody(event.target.value)}
          />
        </label>
        {error ? <p className="form-error">{error}</p> : null}
        <button className="btn primary" type="submit">
          Post thread
        </button>
      </form>

      <div className="stack">
        {threads.map((thread) => {
          const open = openId === thread.id;
          return (
            <article key={thread.id} className="panel thread">
              <button type="button" className="thread-toggle" onClick={() => setOpenId(open ? null : thread.id)}>
                <span>
                  <strong>{thread.title}</strong>
                  <small>
                    {thread.author} · {whenLabel(thread.at)} · {thread.replies.length}{" "}
                    {thread.replies.length === 1 ? "reply" : "replies"}
                  </small>
                </span>
              </button>
              {open ? (
                <div className="thread-body">
                  <p>{thread.body}</p>
                  {thread.replies.map((item) => (
                    <div key={item.id} className="comment">
                      <strong>
                        {item.author}
                        <time>{whenLabel(item.at)}</time>
                      </strong>
                      <p>{item.body}</p>
                    </div>
                  ))}
                  <form className="comment-form" onSubmit={(event) => onReply(event, thread.id)}>
                    <input aria-label="Reply" value={reply} maxLength={400} onChange={(event) => setReply(event.target.value)} />
                    <button className="btn primary" type="submit">
                      Reply
                    </button>
                  </form>
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </main>
  );
}
