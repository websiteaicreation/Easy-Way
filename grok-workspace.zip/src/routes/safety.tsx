import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { useToast } from "@/components/shell";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { addReport, loadReports, type StoredReport } from "@/lib/library";
import { addDbReport } from "@/lib/shelf.functions";

const REASONS = ["Not what I expected", "Copyright", "Harassment", "Spam", "Something else"] as const;

export const Route = createFileRoute("/safety")({
  head: () => ({
    meta: [
      { title: "Trust & Safety — Easy Way" },
      {
        name: "description",
        content: "Community standards, reporting, privacy, and terms for the Easy Way demo.",
      },
    ],
  }),
  component: SafetyPage,
});

function SafetyPage() {
  const toast = useToast();
  const user = useCurrentUser();
  const [target, setTarget] = useState("");
  const [reason, setReason] = useState<(typeof REASONS)[number] | "">("");
  const [details, setDetails] = useState("");
  const [error, setError] = useState("");
  const [reports, setReports] = useState<StoredReport[]>([]);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    setReports(loadReports());
    try {
      const preset = sessionStorage.getItem("afterdark-report-target");
      if (preset) {
        setTarget(preset);
        sessionStorage.removeItem("afterdark-report-target");
      }
    } catch {
      /* leave the field empty */
    }
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (user) {
      const result = await addDbReport({
        data: { slug: "", target, reason, details },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setError("");
      setDetails("");
      setSent(true);
      toast("Report saved for moderators.");
      return;
    }
    const result = addReport({ target, reason, details });
    if (result.error) {
      setError(result.error);
      return;
    }
    setError("");
    setDetails("");
    setSent(true);
    setReports(loadReports());
    toast("Report kept on this device. Sign in to send it to moderators.");
  }

  return (
    <main className="container">
      <header className="page-intro">
        <p className="eyebrow">TRUST & SAFETY</p>
        <h1>Consent, clarity, and a way to say stop.</h1>
        <p>
          Easy Way is an adult-only discovery demo. Signed-in reports are stored for administrators.
          Reports filed while signed out stay in this browser.
        </p>
        <div className="anchor-row">
          <a href="#standards">Standards</a>
          <a href="#report">Report</a>
          <a href="#copyright">Copyright</a>
          <a href="#privacy">Privacy</a>
          <a href="#terms">Terms</a>
        </div>
      </header>
      <div className="safety-grid">
        <div>
          <section className="panel policy" id="standards">
            <h2>Community standards</h2>
            <p>Everyone on a real Easy Way shelf would have to be a verified adult. The demo asks once, in the age gate, and remembers that choice for this browser session.</p>
            <ul>
              <li>Only adults who want to be here, and only where that is legal.</li>
              <li>No one depicted without their consent. No minors, ever — not even fiction presented as a minor.</li>
              <li>Harassment, outing, and non-consensual sharing are out.</li>
              <li>Creators can withdraw a work. A takedown should beat a trending slot.</li>
            </ul>
          </section>
          <section className="panel policy" id="copyright">
            <h2>Copyright and takedowns</h2>
            <p>
              If a real catalog used your work without permission, you could name the title, where it appears,
              and how to reach you. This demo has no media files to remove. Use the report form with the reason
              “Copyright” and it will be stored locally as a sample request.
            </p>
          </section>
          <section className="panel policy" id="privacy">
            <h2>Privacy</h2>
            <p>There is no account. Age confirmation lives in session storage. Uploads, saves, likes, comments, and reports live in local storage on this device. Clearing site data deletes them. The demo does not transmit that information.</p>
          </section>
          <section className="panel policy" id="terms">
            <h2>Terms</h2>
            <p>
              This is a design prototype, not a video host and not a marketplace. Sample titles are fictional.
              Thumbnails are generated with color and shape, not photographs. Do not treat the demo as advice,
              a contract, or a place to upload anyone else’s material.
            </p>
          </section>
        </div>
        <form className="panel policy" id="report" onSubmit={onSubmit}>
          <h2>Report content</h2>
          <p>Tell a moderator what to look at. In this demo the note stays on your device.</p>
          <div className="field">
            <label htmlFor="target">Video or creator</label>
            <input
              id="target"
              value={target}
              maxLength={120}
              placeholder="Title or creator name"
              onChange={(event) => setTarget(event.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="reason">Reason</label>
            <select
              id="reason"
              value={reason}
              onChange={(event) => setReason(event.target.value as (typeof REASONS)[number] | "")}
            >
              <option value="">Choose one</option>
              {REASONS.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="details">Details</label>
            <textarea
              id="details"
              value={details}
              maxLength={500}
              placeholder="What should a moderator know?"
              onChange={(event) => setDetails(event.target.value)}
            />
          </div>
          {error ? <p className="form-error">{error}</p> : null}
          {sent ? <p className="section-kicker">Saved on this device.</p> : null}
          <button className="btn primary" type="submit">
            File report
          </button>
          {reports.length > 0 ? (
            <div className="comments">
              {reports.slice(0, 4).map((report) => (
                <article key={report.id} className="comment">
                  <strong>
                    {report.reason}
                    <time>{report.target}</time>
                  </strong>
                  <p>{report.details}</p>
                </article>
              ))}
            </div>
          ) : null}
        </form>
      </div>
    </main>
  );
}
