import { Link, createFileRoute } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { useEffect, useMemo } from "react";
import { VideoCard } from "@/components/video-card";
import { useBrowse, type SortKey } from "@/lib/browse";
import { CATEGORIES, CREATORS, chipLabel, type Category } from "@/lib/catalog";
import { useLibrary } from "@/lib/use-library";

const PER_PAGE = 9;

export const Route = createFileRoute("/")({
  component: HomePage,
});

function HomePage() {
  const { videos, saved } = useLibrary();
  const query = useBrowse((state) => state.query);
  const category = useBrowse((state) => state.category);
  const lane = useBrowse((state) => state.lane);
  const sort = useBrowse((state) => state.sort);
  const page = useBrowse((state) => state.page);
  const setCategory = useBrowse((state) => state.setCategory);
  const setSort = useBrowse((state) => state.setSort);
  const setPage = useBrowse((state) => state.setPage);
  const setQuery = useBrowse((state) => state.setQuery);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const list = videos.filter((video) => {
      if (category === "Saved" && !saved.includes(video.slug)) return false;
      if (category !== "All" && category !== "Saved" && video.category !== category) return false;
      if (lane === "featured" && !video.featured) return false;
      if (lane === "clips" && video.kind !== "clip") return false;
      if (lane === "shorties" && video.kind !== "short") return false;
      if (lane === "gifs" && video.kind !== "gif") return false;
      if (lane === "photos" && video.kind !== "photo") return false;
      if (lane === "morocco" && video.region !== "morocco") return false;
      if (!needle) return true;
      return `${video.title} ${video.creator} ${video.category}`.toLowerCase().includes(needle);
    });
    const next = [...list];
    if (sort === "popular") next.sort((a, b) => b.viewsNum - a.viewsNum || b.time - a.time);
    if (sort === "newest") next.sort((a, b) => b.time - a.time);
    if (sort === "short") next.sort((a, b) => a.durationSec - b.durationSec);
    return next;
  }, [videos, saved, query, category, lane, sort]);

  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const safePage = Math.min(page, pages);

  useEffect(() => {
    if (page !== safePage) setPage(safePage);
  }, [page, safePage, setPage]);

  const shelfTitle =
    lane === "featured"
      ? "Featured videos"
      : lane === "clips"
        ? "Clips"
        : lane === "shorties"
          ? "Shorties"
          : lane === "recommended"
            ? "Recommended videos"
            : lane === "morocco"
              ? "Hottest in Morocco"
              : lane === "gifs"
                ? "Porn GIFs"
                : lane === "photos"
                  ? "Photos"
                  : category === "Saved"
                    ? "Playlists"
                    : category !== "All"
                      ? category
                      : "Trending videos";

  const shown = filtered.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE);
  const chips = [
    "All",
    ...CATEGORIES,
    "Saved",
  ];

  function countFor(id: string) {
    if (id === "All") return videos.length;
    if (id === "Saved") return videos.filter((video) => saved.includes(video.slug)).length;
    return videos.filter((video) => video.category === id).length;
  }

  return (
    <main className="container">
      <div className="promo">
        <strong>EASY WAY ORIGINALS</strong>
        <span>Discover creator-led stories, interviews, and behind-the-scenes features.</span>
        <Link to="/" hash="creators">
          EXPLORE
        </Link>
      </div>

      <section id="discover" className="section-head">
        <div>
          <p className="section-kicker">
            {filtered.length} {filtered.length === 1 ? "video" : "videos"}
            {query ? ` for “${query}”` : ""}
          </p>
          <h1>
            {shelfTitle}{" "}
            {shelfTitle === "Trending videos" || lane === "morocco" ? (
              <Sparkles className="hot-mark" size={16} aria-hidden="true" />
            ) : null}
          </h1>
        </div>
        <select
          aria-label="Sort videos"
          value={sort}
          onChange={(event) => setSort(event.target.value as SortKey)}
        >
          <option value="popular">Most popular</option>
          <option value="newest">Newest first</option>
          <option value="short">Shortest first</option>
        </select>
      </section>

      <div className="chips-wrap">
        <div className="chips" role="toolbar" aria-label="Filter videos">
          {chips.map((id) => (
            <button
              key={id}
              type="button"
              className={category === id ? "chip selected" : "chip"}
              aria-pressed={category === id}
              onClick={() => setCategory(id)}
            >
              {id === "Saved" && saved.length > 0 ? `Saved · ${saved.length}` : chipLabel(id)}
            </button>
          ))}
        </div>
      </div>

      {shown.length > 0 ? (
        <div className="video-grid">
          {shown.map((video) => (
            <VideoCard key={video.slug} video={video} />
          ))}
        </div>
      ) : (
        <p className="empty">No results found. Try another search or category.</p>
      )}

      <div className="pagination">
        <button
          className="btn ghost"
          type="button"
          disabled={safePage === 1}
          onClick={() => setPage(safePage - 1)}
        >
          Previous
        </button>
        <span>
          Page {safePage} of {pages}
        </span>
        <button
          className="btn ghost"
          type="button"
          disabled={safePage === pages}
          onClick={() => setPage(safePage + 1)}
        >
          Next
        </button>
      </div>

      <section id="categories" className="section-head">
        <div>
          <p className="eyebrow">BROWSE</p>
          <h2>Top categories</h2>
        </div>
      </section>
      <div className="cat-grid">
        {CATEGORIES.map((item) => (
          <button
            key={item}
            type="button"
            className={category === item ? "cat-tile selected" : "cat-tile"}
            onClick={() => {
              setCategory(item as Category);
              document.getElementById("discover")?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
          >
            <strong>{chipLabel(item)}</strong>
            <span>{countFor(item) === 1 ? "1 video" : `${countFor(item)} videos`}</span>
          </button>
        ))}
      </div>

      <section id="creators" className="creator-strip">
        <div>
          <p className="eyebrow">MADE BY CREATORS</p>
          <h2>Creator-first, community-minded.</h2>
          <p>Tools for verified adults, transparent moderation, and respectful communities.</p>
        </div>
        <Link className="btn outline" to="/studio">
          Open creator studio →
        </Link>
      </section>

      <div className="creator-row">
        {CREATORS.map((creator) => (
          <Link key={creator.slug} to="/creator/$slug" params={{ slug: creator.slug }} className="creator-card">
            <span className={`avatar thumb-art art-${creator.art}`} aria-hidden="true">
              <span className="shape" />
            </span>
            <span>
              <h3>{creator.name}</h3>
              <p>
                {creator.place} — {creator.bio}
              </p>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
