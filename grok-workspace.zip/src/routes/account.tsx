import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { VideoCard } from "@/components/video-card";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { myLibrary } from "@/lib/shelf.functions";
import { CREATORS } from "@/lib/catalog";
import { useLibrary } from "@/lib/use-library";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [{ title: "Your library — Easy Way" }],
  }),
  component: AccountPage,
});

function AccountPage() {
  const { videos, saved, likes, uploads, memberName, follows } = useLibrary();
  const { user, isPending } = useCurrentUserState();
  const [accountLikes, setAccountLikes] = useState<string[]>([]);
  const [accountFavorites, setAccountFavorites] = useState<string[]>([]);
  const [subscriptions, setSubscriptions] = useState<string[]>([]);
  const [role, setRole] = useState("member");
  const savedVideos = videos.filter((video) => saved.includes(video.slug));
  const likedVideos = videos.filter((video) => likes.includes(video.slug));
  const favoriteVideos = videos.filter((video) => accountFavorites.includes(video.slug));

  const userId = user?.id;

  useEffect(() => {
    if (!userId) return;
    void myLibrary()
      .then((library) => {
        setRole(library.role);
        setAccountLikes(library.likes);
        setAccountFavorites(library.favorites);
        setSubscriptions(library.subscriptions);
      })
      .catch(() => {
        setAccountLikes([]);
        setAccountFavorites([]);
      });
  }, [userId]);

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">THIS DEVICE</p>
        <h1>{user?.displayName || memberName || "Your library"}</h1>
        <p>
          {user
            ? "Signed-in likes, favorites, and subscriptions are stored in the database."
            : isPending
              ? "Checking your session…"
              : "Sign in to keep likes, favorites, and subscriptions on your account. This device still remembers a local copy."}
        </p>
        <div className="action-row">
          {isPending ? null : user ? <UserButton /> : <Link className="btn primary" to="/login">Sign in</Link>}
          {role === "admin" ? (
            <Link className="btn ghost" to="/admin">
              Moderation
            </Link>
          ) : null}
          <Link className="btn ghost" to="/studio">
            Creator Studio
          </Link>
        </div>
      </header>

      {user ? (
        <>
        <section>
          <div className="section-head">
            <h2>Account favorites</h2>
            <span className="section-kicker">
              {accountFavorites.length} saved · {accountLikes.length} likes
            </span>
          </div>
          {favoriteVideos.length > 0 ? (
            <div className="video-grid">
              {favoriteVideos.map((video) => (
                <VideoCard key={video.slug} video={video} />
              ))}
            </div>
          ) : (
            <p className="empty">Nothing in your account favorites yet.</p>
          )}
        </section>
        <section className="panel">
          <h2>Subscriptions</h2>
          {subscriptions.length === 0 ? (
            <p className="section-kicker">Follow a creator while signed in to subscribe.</p>
          ) : (
            subscriptions.map((slug) => {
              const creator = CREATORS.find((item) => item.slug === slug);
              return (
                <div key={slug} className="upload-row">
                  <div>
                    <h3>{creator?.name ?? slug}</h3>
                    <p className="section-kicker">{creator?.place ?? "Creator"}</p>
                  </div>
                  {creator ? (
                    <Link className="btn ghost" to="/creator/$slug" params={{ slug: creator.slug }}>
                      Open
                    </Link>
                  ) : null}
                </div>
              );
            })
          )}
        </section>
        </>
      ) : null}

      <section>
        <div className="section-head">
          <h2>Saved</h2>
          <span className="section-kicker">{savedVideos.length}</span>
        </div>
        {savedVideos.length > 0 ? (
          <div className="video-grid">
            {savedVideos.map((video) => (
              <VideoCard key={video.slug} video={video} />
            ))}
          </div>
        ) : (
          <p className="empty">Nothing saved yet. Use Save on a video.</p>
        )}
      </section>

      <section>
        <div className="section-head">
          <h2>Liked</h2>
          <span className="section-kicker">{likedVideos.length}</span>
        </div>
        {likedVideos.length > 0 ? (
          <div className="video-grid">
            {likedVideos.map((video) => (
              <VideoCard key={video.slug} video={video} />
            ))}
          </div>
        ) : (
          <p className="empty">No likes yet.</p>
        )}
      </section>

      <section className="panel">
        <h2>Published here</h2>
        {uploads.length === 0 ? <p className="section-kicker">Studio uploads will show up in this list.</p> : null}
        {uploads.map((video) => (
          <div key={video.slug} className="upload-row">
            <div>
              <h3>{video.title}</h3>
              <p className="section-kicker">
                {video.creator} · {video.category}
              </p>
            </div>
            <Link className="btn ghost" to="/watch/$slug" params={{ slug: video.slug }}>
              Open
            </Link>
          </div>
        ))}
        <p className="section-kicker">Following {follows.length}.</p>
      </section>
    </main>
  );
}
