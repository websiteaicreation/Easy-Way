import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — Easy Way" }] }),
  component: LoginPage,
});

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (isPending) return <main className="container"><p className="empty">Checking your session…</p></main>;
  if (user) return <RedirectToSignIn to="/" />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (password.length < 8) {
      setError("Use at least 8 characters.");
      return;
    }
    setBusy(true);
    const result =
      mode === "up"
        ? await authClient.signUp.email({ email, password, name: name.trim() || "Member", callbackURL: "/" })
        : await authClient.signIn.email({ email, password, callbackURL: "/" });
    setBusy(false);
    if (result.error) {
      setError(result.error.message ?? "Could not sign you in.");
      return;
    }
    void navigate({ to: "/" });
  }

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">ACCOUNT</p>
        <h1>{mode === "up" ? "Create an account" : "Sign in"}</h1>
        <p>Email stays on this app. Google and X use the sign-in window.</p>
      </header>
      {authEnabled ? (
        <form className="panel" onSubmit={(event) => void onSubmit(event)}>
          {mode === "up" ? (
            <label className="field">
              Name
              <input value={name} maxLength={32} onChange={(event) => setName(event.target.value)} />
            </label>
          ) : null}
          <label className="field">
            Email
            <input
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </label>
          <label className="field">
            Password
            <input
              type="password"
              autoComplete={mode === "up" ? "new-password" : "current-password"}
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </label>
          {error ? <p className="form-error">{error}</p> : null}
          <div className="action-row">
            <button className="btn primary" type="submit" disabled={busy}>
              {busy ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"}
            </button>
            <button
              className="btn ghost"
              type="button"
              onClick={() => {
                setMode(mode === "up" ? "in" : "up");
                setError("");
              }}
            >
              {mode === "up" ? "I already have an account" : "Need an account?"}
            </button>
          </div>
          <div className="stack">
            {GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                className="btn ghost"
                type="button"
                onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
              >
                Continue with {provider.label}
              </button>
            ))}
          </div>
        </form>
      ) : (
        <p className="empty">Sign-in is turned off.</p>
      )}
    </main>
  );
}
