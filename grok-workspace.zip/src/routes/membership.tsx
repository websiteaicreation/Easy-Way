import { Link, createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { useState, type FormEvent } from "react";
import { useToast } from "@/components/shell";
import { setMemberName } from "@/lib/library";
import { useLibrary } from "@/lib/use-library";

const PERKS = [
  "The full shelf stays open — featured, clips, shorties, GIFs, and photos.",
  "A member name on this device, shown on your library.",
  "Saved videos and likes stay with you in this browser.",
  "Creator Studio publishing, without a paywall.",
];

export const Route = createFileRoute("/membership")({
  head: () => ({
    meta: [{ title: "Membership — Easy Way" }],
  }),
  component: MembershipPage,
});

function MembershipPage() {
  const toast = useToast();
  const { memberName } = useLibrary();
  const [name, setName] = useState(memberName);
  const [error, setError] = useState("");

  function onJoin(event: FormEvent) {
    event.preventDefault();
    const next = name.trim();
    if (next.length < 2) {
      setError("Add the name you want on this device.");
      return;
    }
    setError("");
    setMemberName(next);
    toast("Membership saved on this device. Nothing was charged.");
  }

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">MEMBERSHIP</p>
        <h1>Full Easy Way</h1>
        <p>
          This is a demo membership. Joining stores a name in this browser. There is no payment and no account
          server.
        </p>
      </header>
      <section className="panel">
        <h2>{memberName ? `You’re in as ${memberName}` : "What you get"}</h2>
        <ul className="perk-list">
          {PERKS.map((perk) => (
            <li key={perk}>
              <Check size={16} aria-hidden="true" />
              <span>{perk}</span>
            </li>
          ))}
        </ul>
        <form onSubmit={onJoin}>
          <label className="field">
            Name on this device
            <input
              value={name}
              maxLength={32}
              placeholder="How should the shelf greet you?"
              onChange={(event) => setName(event.target.value)}
            />
          </label>
          {error ? <p className="form-error">{error}</p> : null}
          <div className="action-row">
            <button className="btn primary" type="submit">
              {memberName ? "Update name" : "Join on this device"}
            </button>
            {memberName ? (
              <button
                className="btn ghost"
                type="button"
                onClick={() => {
                  setMemberName("");
                  setName("");
                  toast("Membership cleared on this device.");
                }}
              >
                Leave
              </button>
            ) : null}
            <Link className="btn ghost" to="/">
              Back to the shelf
            </Link>
          </div>
        </form>
      </section>
    </main>
  );
}
