import { Link, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/$")({
  head: () => ({
    meta: [{ title: "Page not found — Easy Way" }],
  }),
  component: MissingPage,
});

function MissingPage() {
  return (
    <main className="container">
      <div className="empty">
        <p className="eyebrow">404</p>
        <h1>That page is not on the shelf.</h1>
        <p>The link may be old, or it was never part of this demo.</p>
        <Link className="btn primary" to="/">
          Back to trending
        </Link>
      </div>
    </main>
  );
}
