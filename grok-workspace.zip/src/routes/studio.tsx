import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { useToast } from "@/components/shell";
import { CATEGORIES, type Category } from "@/lib/catalog";
import { addUpload, removeUpload } from "@/lib/library";
import { useLibrary } from "@/lib/use-library";

export const Route = createFileRoute("/studio")({
  head: () => ({
    meta: [{ title: "Creator studio — Easy Way" }],
  }),
  component: StudioPage,
});

function StudioPage() {
  const { uploads, saved, videos } = useLibrary();
  const toast = useToast();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [creator, setCreator] = useState("");
  const [category, setCategory] = useState<Category>(CATEGORIES[0]);
  const [duration, setDuration] = useState("");
  const [synopsis, setSynopsis] = useState("");
  const [error, setError] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const result = addUpload({ title, creator, category, duration, synopsis });
    if (result.error || !result.video) {
      setError(result.error ?? "Could not save that video.");
      return;
    }
    setError("");
    setTitle("");
    setDuration("");
    setSynopsis("");
    toast("Published to this device. It now appears in Trending.");
    void navigate({ to: "/watch/$slug", params: { slug: result.video.slug } });
  }

  return (
    <main className="container">
      <header className="page-intro">
        <p className="eyebrow">CREATOR STUDIO</p>
        <h1>Publish to your shelf</h1>
        <p>
          This demo keeps uploads, saves, and comments in this browser only. Nothing is sent to a server,
          and cards stay abstract — add a title and synopsis, not a media file.
        </p>
      </header>
      <div className="studio-grid">
        <form className="panel" onSubmit={onSubmit}>
          <h2>New video</h2>
          <div className="field">
            <label htmlFor="title">Title</label>
            <input
              id="title"
              value={title}
              maxLength={80}
              placeholder="A quiet evening — creator diary"
              onChange={(event) => setTitle(event.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="creator">Creator</label>
            <input
              id="creator"
              value={creator}
              maxLength={40}
              placeholder="Your studio name"
              onChange={(event) => setCreator(event.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="category">Category</label>
            <select
              id="category"
              value={category}
              onChange={(event) => setCategory(event.target.value as Category)}
            >
              {CATEGORIES.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="duration">Duration</label>
            <input
              id="duration"
              value={duration}
              inputMode="numeric"
              placeholder="08:16"
              onChange={(event) => setDuration(event.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="synopsis">Synopsis</label>
            <textarea
              id="synopsis"
              value={synopsis}
              maxLength={280}
              placeholder="What will someone understand after watching?"
              onChange={(event) => setSynopsis(event.target.value)}
            />
          </div>
          {error ? <p className="form-error">{error}</p> : null}
          <button className="btn primary" type="submit">
            Publish on this device
          </button>
        </form>
        <aside className="panel">
          <div className="stat-row">
            <div className="stat">
              <b>{uploads.length}</b>
              <span>Your uploads</span>
            </div>
            <div className="stat">
              <b>{saved.length}</b>
              <span>Saved</span>
            </div>
            <div className="stat">
              <b>{videos.length}</b>
              <span>On the shelf</span>
            </div>
          </div>
          <h2>Your uploads</h2>
          {uploads.length === 0 ? (
            <p className="section-kicker">Nothing published from this browser yet.</p>
          ) : (
            uploads.map((video) => (
              <div key={video.slug} className="upload-row">
                <div>
                  <h3>{video.title}</h3>
                  <p>
                    {video.category} · {video.duration}
                  </p>
                </div>
                <div>
                  <Link to="/watch/$slug" params={{ slug: video.slug }}>
                    Open
                  </Link>
                  <button
                    className="icon-text"
                    type="button"
                    onClick={() => {
                      removeUpload(video.slug);
                      toast("Removed from this device.");
                    }}
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))
          )}
        </aside>
      </div>
    </main>
  );
}
