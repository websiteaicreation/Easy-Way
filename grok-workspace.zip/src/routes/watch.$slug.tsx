import { Link, createFileRoute } from "@tanstack/react-router";
import { BadgeCheck, Flag, Heart, Share2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { Player } from "@/components/player";
import { useToast } from "@/components/shell";
import { RelatedCard } from "@/components/video-card";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import {
  SEED_COMMENTS,
  creatorProfile,
  getCatalogVideo,
  relatedVideos,
} from "@/lib/catalog";
import { addComment, loadComments, type StoredComment } from "@/lib/library";
import { addDbComment, listDbComments, setReaction } from "@/lib/shelf.functions";
import { useLibrary } from "@/lib/use-library";

export const Route = createFileRoute("/watch/$slug")({
  head: ({ params }) => {
    const video = getCatalogVideo(params.slug);
    return {
      meta: [{ title: video ? `${video.title} — Easy Way` : "Watch — Easy Way" }],
    };
  },
  component: WatchPage,
});

function whenLabel(at: number) {
  if (!at) return "Featured";
  const delta = Date.now() - at;
  if (delta < 60_000) return "Just now";
  const minutes = Math.floor(delta / 60_000);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function Comments({ slug }: { slug: string }) {
  const toast = useToast();
  const user = useCurrentUser();
  const [items, setItems] = useState<StoredComment[]>([]);
  const [remote, setRemote] = useState<{ id: number; user: string; body: string }[]>([]);
  const [name, setName] = useState("Guest");
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  function loadLocal() {
    const mine = loadComments(slug);
    const seeds = (SEED_COMMENTS[slug] ?? []).map((comment, index) => ({
      id: `seed-${slug}-${index}`,
      slug,
      user: comment.user,
      text: comment.text,
      at: 0,
    }));
    setItems([...mine, ...seeds]);
  }

  useEffect(() => {
    loadLocal();
    setText("");
    setError("");
    void listDbComments({ data: slug })
      .then(setRemote)
      .catch(() => setRemote([]));
  }, [slug]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (user) {
      const result = await addDbComment({ data: { slug, body: text } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setError("");
      setText("");
      const next = await listDbComments({ data: slug });
      setRemote(next);
      toast("Comment saved to your account.");
      return;
    }
    const result = addComment(slug, name, text);
    if (result.error) {
      setError(result.error);
      return;
    }
    setError("");
    setText("");
    loadLocal();
    toast("Comment saved on this device. Sign in to keep it on your account.");
  }

  return (
    <section className="comments" aria-labelledby="comments-heading">
      <h2 id="comments-heading">Comments</h2>
      {items.length === 0 ? <p className="section-kicker">No comments yet. Be the first.</p> : null}
      {remote.map((comment) => (
        <article key={`db-${comment.id}`} className="comment">
          <strong>
            {comment.user}
            <time>Account</time>
          </strong>
          <p>{comment.body}</p>
        </article>
      ))}
      {items.map((comment) => (
        <article key={comment.id} className="comment">
          <strong>
            {comment.user}
            <time>{whenLabel(comment.at)}</time>
          </strong>
          <p>{comment.text}</p>
        </article>
      ))}
      <form className="comment-form" onSubmit={onSubmit}>
          {user ? null : (
            <input
              aria-label="Display name"
              value={name}
              maxLength={32}
              onChange={(event) => setName(event.target.value)}
            />
          )}
        <input
          aria-label="Comment"
          placeholder="Add a comment"
          value={text}
          maxLength={400}
          onChange={(event) => setText(event.target.value)}
        />
        <button className="btn primary" type="submit">
          Post
        </button>
        {error ? <p className="form-error">{error}</p> : null}
      </form>
    </section>
  );
}

function WatchPage() {
  const { slug } = Route.useParams();
  const { videos, ready, isSaved, isLiked, toggleSaved, toggleLike } = useLibrary();
  const user = useCurrentUser();
  const toast = useToast();
  const video = videos.find((item) => item.slug === slug);
  const known = Boolean(getCatalogVideo(slug));

  if (!video && !known && !ready) {
    return (
      <main className="container">
        <p className="empty">Loading the shelf…</p>
      </main>
    );
  }

  if (!video) {
    return (
      <main className="container">
        <div className="empty">
          <p className="eyebrow">MISSING</p>
          <h1>This video is not on the shelf.</h1>
          <p>It may have been removed from this device.</p>
          <Link className="btn primary" to="/">
            Back to trending
          </Link>
        </div>
      </main>
    );
  }

  const current = video;
  const profile = creatorProfile(current.creator);
  const related = relatedVideos(videos, current);

  async function share() {
    try {
      await navigator.clipboard.writeText(window.location.href);
      toast("Link copied.");
    } catch {
      toast("Could not copy the link. Use the browser share menu instead.");
    }
  }

  function report() {
    try {
      sessionStorage.setItem("afterdark-report-target", current.title);
    } catch {
      /* the report form still works without a prefilled title */
    }
  }

  return (
    <main className="container watch-layout">
      <article>
        <Link className="back-link" to="/" hash="discover">
          ← Trending
        </Link>
        <Player video={current} />
        <h1 className="watch-title">{current.title}</h1>
        <div className="video-meta">
          <span className="creator">
            {current.creator}
            <BadgeCheck className="verified" size={14} aria-label="Verified creator" />
          </span>
          <span className="views">
            {current.views} views · {current.duration}
          </span>
        </div>
        <div className="watch-actions">
          <button
            className="btn ghost"
            type="button"
            aria-pressed={isLiked(current.slug)}
            onClick={() => {
              const liked = isLiked(current.slug);
              toggleLike(current.slug);
              if (user) {
                void setReaction({ data: { slug: current.slug, kind: "like", on: !liked } });
                toast(liked ? "Like removed from your account." : "Liked on your account.");
              } else {
                toast(liked ? "Like removed on this device." : "Liked here. Sign in to keep it on your account.");
              }
            }}
          >
            <Heart size={16} fill={isLiked(current.slug) ? "currentColor" : "none"} />
            {isLiked(current.slug) ? "Liked" : "Like"}
          </button>
          <button
            className="btn ghost"
            type="button"
            aria-pressed={isSaved(current.slug)}
            onClick={() => {
              const saved = isSaved(current.slug);
              toggleSaved(current.slug);
              if (user) {
                void setReaction({ data: { slug: current.slug, kind: "favorite", on: !saved } });
                toast(saved ? "Removed from your favorites." : "Saved to your favorites.");
              } else {
                toast(saved ? "Removed on this device." : "Saved here. Sign in to keep it on your account.");
              }
            }}
          >
            {isSaved(current.slug) ? "Saved" : "Save"}
          </button>
          <button className="btn ghost" type="button" onClick={() => void share()}>
            <Share2 size={16} />
            Share
          </button>
          <Link className="btn ghost" to="/safety" hash="report" onClick={report}>
            <Flag size={16} />
            Report
          </Link>
        </div>
        <p className="synopsis">{current.synopsis}</p>
        <div className="creator-panel">
          <span className={`avatar thumb-art art-${current.art}`} aria-hidden="true">
            <span className="shape" />
          </span>
          <div>
            <h2>{current.creator}</h2>
            <p>
              {profile ? `${profile.place} — ${profile.bio}` : "Independent creator on this demo shelf."}
            </p>
            {profile ? (
              <Link className="back-link" to="/creator/$slug" params={{ slug: profile.slug }}>
                View profile →
              </Link>
            ) : null}
          </div>
        </div>
        <Comments slug={current.slug} />
      </article>
      <aside className="related">
        <h2>Up next</h2>
        {related.map((item) => (
          <RelatedCard key={item.slug} video={item} />
        ))}
      </aside>
    </main>
  );
}
