import { Link, createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

const POSTS = [
  {
    id: "reports",
    kicker: "TRUST",
    title: "What happens after you file a report",
    lede: "A report on this demo stays in the browser. Here is the path a real desk would follow.",
    body: "You name the title, pick a reason, and add enough detail that someone else could find the same card. On a live site that note would go to a moderator queue, not a public thread. Copyright claims use the same form and should include where the original lives. Nothing here is sent to a server.",
  },
  {
    id: "sets",
    kicker: "STUDIO",
    title: "Before you publish from Creator Studio",
    lede: "The studio writes a card onto this device and drops it into Trending.",
    body: "Use a title someone can search, a duration in minutes and seconds, and a synopsis that says what the piece is about. Categories match the shelf chips. Removing a card only removes your upload — the sample shelf stays. If you are testing a real launch later, replace the sample policies before anyone else can see the studio.",
  },
  {
    id: "region",
    kicker: "SHELF",
    title: "Why Hottest in Morocco is its own lane",
    lede: "Regional shelves are a filter, not a ranking of people.",
    body: "The Morocco lane only shows cards tagged to that region. It sits next to Featured, Clips, and Shorties so a visitor in Marrakech can start close to home and still jump to the full catalog. The star in the menu marks the lane. It does not change how reports or saves work.",
  },
];

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [{ title: "Stories — Easy Way" }],
  }),
  component: BlogPage,
});

function BlogPage() {
  const [open, setOpen] = useState(POSTS[0]?.id ?? "");

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">STORIES</p>
        <h1>From the desk</h1>
        <p>Notes on the shelf, the studio, and how reports are meant to work.</p>
      </header>
      <div className="stack">
        {POSTS.map((post) => {
          const shown = open === post.id;
          return (
            <article key={post.id} className="panel thread">
              <button type="button" className="thread-toggle" onClick={() => setOpen(shown ? "" : post.id)}>
                <span>
                  <small className="eyebrow">{post.kicker}</small>
                  <strong>{post.title}</strong>
                  <small>{post.lede}</small>
                </span>
              </button>
              {shown ? (
                <div className="thread-body">
                  <p>{post.body}</p>
                  <Link className="back-link" to="/safety">
                    Trust & Safety →
                  </Link>
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </main>
  );
}
