import { Link, createFileRoute } from "@tanstack/react-router";
import { BadgeCheck } from "lucide-react";
import { VideoCard } from "@/components/video-card";
import { useToast } from "@/components/shell";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { getCreator } from "@/lib/catalog";
import { setSubscription } from "@/lib/shelf.functions";
import { useLibrary } from "@/lib/use-library";

export const Route = createFileRoute("/creator/$slug")({
  head: ({ params }) => {
    const creator = getCreator(params.slug);
    return {
      meta: [{ title: creator ? `${creator.name} — Easy Way` : "Creator — Easy Way" }],
    };
  },
  component: CreatorPage,
});

function CreatorPage() {
  const { slug } = Route.useParams();
  const creator = getCreator(slug);
  const toast = useToast();
  const { videos, follows, toggleFollow } = useLibrary();
  const user = useCurrentUser();

  if (!creator) {
    return (
      <main className="container">
        <div className="empty">
          <p className="eyebrow">MISSING</p>
          <h1>That creator is not on the shelf.</h1>
          <Link className="btn primary" to="/" hash="creators">
            Browse creators
          </Link>
        </div>
      </main>
    );
  }

  const theirs = videos.filter((video) => video.creator === creator.name);
  const following = follows.includes(creator.slug);

  return (
    <main className="container page-stack">
      <header className="creator-hero">
        <span className={`avatar large thumb-art art-${creator.art}`} aria-hidden="true">
          <span className="shape" />
        </span>
        <div>
          <p className="eyebrow">{creator.place.toUpperCase()}</p>
          <h1>
            {creator.name}
            <BadgeCheck className="verified" size={18} aria-label="Verified creator" />
          </h1>
          <p>{creator.bio}</p>
          <div className="action-row">
            <button
              className="btn primary"
              type="button"
              aria-pressed={following}
              onClick={() => {
                toggleFollow(creator.slug);
                if (user) {
                  void setSubscription({ data: { slug: creator.slug, on: !following } });
                  toast(following ? `Unsubscribed from ${creator.name}.` : `Subscribed to ${creator.name}.`);
                } else {
                  toast(
                    following
                      ? `Unfollowed ${creator.name} on this device.`
                      : `Following ${creator.name} here. Sign in to subscribe.`,
                  );
                }
              }}
            >
              {following ? "Following" : "Follow"}
            </button>
            <Link className="btn ghost" to="/" hash="discover">
              {theirs.length === 1 ? "1 video" : `${theirs.length} videos`}
            </Link>
          </div>
        </div>
      </header>
      {theirs.length > 0 ? (
        <div className="video-grid">
          {theirs.map((video) => (
            <VideoCard key={video.slug} video={video} />
          ))}
        </div>
      ) : (
        <p className="empty">No videos from this creator yet.</p>
      )}
    </main>
  );
}
