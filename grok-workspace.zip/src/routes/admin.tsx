import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { adminQueue, moderateReport, verifyCreator } from "@/lib/shelf.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Moderation — Easy Way" }] }),
  component: AdminPage,
});

type Queue = Extract<Awaited<ReturnType<typeof adminQueue>>, { ok: true }>;

function AdminPage() {
  const { user, isPending } = useCurrentUserState();
  const [queue, setQueue] = useState<Queue | null>(null);
  const [error, setError] = useState("");

  function refresh() {
    void adminQueue()
      .then((result) => {
        if (!result.ok) {
          setError(result.error);
          setQueue(null);
          return;
        }
        setError("");
        setQueue(result);
      })
      .catch(() => setError("Could not load the queue."));
  }

  const userId = user?.id;

  useEffect(() => {
    if (!userId) return;
    refresh();
  }, [userId]);

  if (isPending) return <main className="container"><p className="empty">Checking your session…</p></main>;
  if (!user) return <RedirectToSignIn />;

  return (
    <main className="container page-stack">
      <header className="page-intro">
        <p className="eyebrow">ADMIN</p>
        <h1>Moderation</h1>
        <p>Reports and verification records. Only an administrator account can change them.</p>
      </header>
      {error ? <p className="empty">{error}</p> : null}
      {queue ? (
        <>
          <section className="panel">
            <h2>Reports</h2>
            {queue.reports.length === 0 ? <p className="section-kicker">No reports yet.</p> : null}
            {queue.reports.map((report) => (
              <article key={report.id} className="comment">
                <strong>
                  {report.target} · {report.status}
                </strong>
                <p>
                  {report.reason}. {report.details}
                </p>
                {report.status === "pending" ? (
                  <div className="action-row">
                    <button
                      className="btn ghost"
                      type="button"
                      onClick={() => {
                        void moderateReport({ data: { id: report.id, action: "reviewed", note: "" } }).then(refresh);
                      }}
                    >
                      Mark reviewed
                    </button>
                    <button
                      className="btn ghost"
                      type="button"
                      onClick={() => {
                        void moderateReport({ data: { id: report.id, action: "dismissed", note: "" } }).then(refresh);
                      }}
                    >
                      Dismiss
                    </button>
                    <button
                      className="btn ghost"
                      type="button"
                      onClick={() => {
                        void moderateReport({ data: { id: report.id, action: "removed", note: "" } }).then(refresh);
                      }}
                    >
                      Remove
                    </button>
                  </div>
                ) : null}
              </article>
            ))}
          </section>
          <section className="panel">
            <h2>Verification</h2>
            {queue.creators.map((creator) => (
              <div key={creator.id} className="upload-row">
                <div>
                  <h3>{creator.name}</h3>
                  <p className="section-kicker">{creator.verified ? "Verified" : "Not verified"}</p>
                </div>
                <button
                  className="btn ghost"
                  type="button"
                  onClick={() => {
                    void verifyCreator({
                      data: {
                        id: creator.id,
                        status: creator.verified ? "rejected" : "verified",
                        note: "",
                      },
                    }).then(refresh);
                  }}
                >
                  {creator.verified ? "Remove" : "Verify"}
                </button>
              </div>
            ))}
          </section>
        </>
      ) : null}
    </main>
  );
}
